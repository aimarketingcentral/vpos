var class_p_o_s_link_admin_1_1_device_1_1_camera_scan_request =
[
    [ "Reader", "class_p_o_s_link_admin_1_1_device_1_1_camera_scan_request.html#a6280d418b6a2a67ca1a8d0d981ca7d66", null ],
    [ "Timeout", "class_p_o_s_link_admin_1_1_device_1_1_camera_scan_request.html#aead5b7a241819ce51828ac35115e4d72", null ]
];