var class_p_o_s_link_admin_1_1_manage_1_1_set_apple_pay_vas_parameters_request =
[
    [ "ApplePayVasData", "class_p_o_s_link_admin_1_1_manage_1_1_set_apple_pay_vas_parameters_request.html#a354278ae25c9d99bf21b638ce6775fd2", null ],
    [ "VasMode", "class_p_o_s_link_admin_1_1_manage_1_1_set_apple_pay_vas_parameters_request.html#a715e383cde730bfc6a53dc71e39ee7e5", null ]
];