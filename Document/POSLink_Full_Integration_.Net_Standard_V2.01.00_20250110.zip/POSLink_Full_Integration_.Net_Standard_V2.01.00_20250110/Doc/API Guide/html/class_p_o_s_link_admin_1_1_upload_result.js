var class_p_o_s_link_admin_1_1_upload_result =
[
    [ "POSLinkErrorCode", "class_p_o_s_link_admin_1_1_upload_result.html#abf141dd9f8fc8bbc2e4b65ea77bfb5d2", [
      [ "Ok", "class_p_o_s_link_admin_1_1_upload_result.html#abf141dd9f8fc8bbc2e4b65ea77bfb5d2aa60852f204ed8028c1c58808b746d115", null ],
      [ "SftpConnectError", "class_p_o_s_link_admin_1_1_upload_result.html#abf141dd9f8fc8bbc2e4b65ea77bfb5d2ae52492f8205eb35b38ababafc023ad31", null ],
      [ "UploadDataError", "class_p_o_s_link_admin_1_1_upload_result.html#abf141dd9f8fc8bbc2e4b65ea77bfb5d2af74330c2b9d0894958ca734fddde281d", null ],
      [ "NoDataToUpload", "class_p_o_s_link_admin_1_1_upload_result.html#abf141dd9f8fc8bbc2e4b65ea77bfb5d2af9ab0c6ba573124450428f5b1bd028ef", null ],
      [ "SftpParameterNotReceived", "class_p_o_s_link_admin_1_1_upload_result.html#abf141dd9f8fc8bbc2e4b65ea77bfb5d2ad1414e89f6ed4631398f821d51405cee", null ]
    ] ],
    [ "TerminalErrorCode", "class_p_o_s_link_admin_1_1_upload_result.html#adbf3ee69cff084c804509ad7bb09f3bd", [
      [ "Ok", "class_p_o_s_link_admin_1_1_upload_result.html#adbf3ee69cff084c804509ad7bb09f3bdaa60852f204ed8028c1c58808b746d115", null ],
      [ "CommunicationError", "class_p_o_s_link_admin_1_1_upload_result.html#adbf3ee69cff084c804509ad7bb09f3bdadb3f55cd913a0331acdfa5fa1da8323a", null ],
      [ "Abort", "class_p_o_s_link_admin_1_1_upload_result.html#adbf3ee69cff084c804509ad7bb09f3bda727b63583e01fa2b3952dab580c84dc2", null ],
      [ "ConnectError", "class_p_o_s_link_admin_1_1_upload_result.html#adbf3ee69cff084c804509ad7bb09f3bda3b26f2ffccae97443db33944eda7b269", null ],
      [ "UnknownError", "class_p_o_s_link_admin_1_1_upload_result.html#adbf3ee69cff084c804509ad7bb09f3bdabfaef30f1c8011c5cefa38ae470fb7aa", null ],
      [ "SftpCommunicationError", "class_p_o_s_link_admin_1_1_upload_result.html#adbf3ee69cff084c804509ad7bb09f3bda8de53349d7d429685b50b0a1509daabf", null ],
      [ "NoDataToUpload", "class_p_o_s_link_admin_1_1_upload_result.html#adbf3ee69cff084c804509ad7bb09f3bdaf9ab0c6ba573124450428f5b1bd028ef", null ]
    ] ],
    [ "UploadResult", "class_p_o_s_link_admin_1_1_upload_result.html#a29679e51e032a459ce92f58ccf53ccc8", null ],
    [ "IsSuccessful", "class_p_o_s_link_admin_1_1_upload_result.html#a117bc7520df59b246c5ab6cf0d8dbc4f", null ],
    [ "POSLinkUploadErrorCode", "class_p_o_s_link_admin_1_1_upload_result.html#aeb1c192b260a9629c7f04189cf80c700", null ],
    [ "Sn", "class_p_o_s_link_admin_1_1_upload_result.html#af09fb511a00123f54aad570bf6624e58", null ],
    [ "TerminalUploadErrorCode", "class_p_o_s_link_admin_1_1_upload_result.html#ad7d6cedc7dfb1ac1463b26e1903aa752", null ]
];