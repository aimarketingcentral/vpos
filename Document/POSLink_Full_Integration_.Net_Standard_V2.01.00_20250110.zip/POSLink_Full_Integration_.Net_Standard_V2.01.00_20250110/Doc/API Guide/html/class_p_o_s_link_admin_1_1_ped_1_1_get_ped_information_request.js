var class_p_o_s_link_admin_1_1_ped_1_1_get_ped_information_request =
[
    [ "KeySlot", "class_p_o_s_link_admin_1_1_ped_1_1_get_ped_information_request.html#aaa74bc10f87bdeacdf154f1a816e6ee9", null ],
    [ "KeyType", "class_p_o_s_link_admin_1_1_ped_1_1_get_ped_information_request.html#a19c890c58a7802470230f32e1cfb1396", null ]
];