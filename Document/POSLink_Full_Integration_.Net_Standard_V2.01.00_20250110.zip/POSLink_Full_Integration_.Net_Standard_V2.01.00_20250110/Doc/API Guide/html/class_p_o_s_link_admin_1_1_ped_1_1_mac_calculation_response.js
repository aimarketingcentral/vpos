var class_p_o_s_link_admin_1_1_ped_1_1_mac_calculation_response =
[
    [ "Ksn", "class_p_o_s_link_admin_1_1_ped_1_1_mac_calculation_response.html#a43d5c6cc8fba834c8362d345f6cc175d", null ],
    [ "ResultData", "class_p_o_s_link_admin_1_1_ped_1_1_mac_calculation_response.html#af964099c1a7f620794278f4f2681b4d6", null ]
];