var class_p_o_s_link_admin_1_1_code104000 =
[
    [ "DeviceCallAccessDenied", "class_p_o_s_link_admin_1_1_code104000.html#ad20b3b161510e357f877df839064f0e8", null ],
    [ "LocationAccessDenied", "class_p_o_s_link_admin_1_1_code104000.html#aac12a10619bab9ce9885a93a1f2b2f6f", null ]
];