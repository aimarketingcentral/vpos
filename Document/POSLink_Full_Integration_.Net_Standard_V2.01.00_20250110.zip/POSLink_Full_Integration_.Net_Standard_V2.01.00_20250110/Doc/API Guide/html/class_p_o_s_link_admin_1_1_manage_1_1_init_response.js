var class_p_o_s_link_admin_1_1_manage_1_1_init_response =
[
    [ "AppActivated", "class_p_o_s_link_admin_1_1_manage_1_1_init_response.html#a01a4f2c13cbe2f7b73f4d98c8ba22b1c", null ],
    [ "AppName", "class_p_o_s_link_admin_1_1_manage_1_1_init_response.html#ad9e36d70c659cb41d1fb25aff67260f0", null ],
    [ "AppVersion", "class_p_o_s_link_admin_1_1_manage_1_1_init_response.html#a7787833fc679cc5cb168d4c1fc815203", null ],
    [ "CharsPerLine", "class_p_o_s_link_admin_1_1_manage_1_1_init_response.html#a0f63f58c0f55aa8425bc3b6d0ffafd5f", null ],
    [ "HardwareConfigurationBitmap", "class_p_o_s_link_admin_1_1_manage_1_1_init_response.html#a60b4c7eac0bece0cfd0a2499e709ccb0", null ],
    [ "LicenseExpiry", "class_p_o_s_link_admin_1_1_manage_1_1_init_response.html#a69f6504e913211a60e82973d71d949e4", null ],
    [ "LinesPerScreen", "class_p_o_s_link_admin_1_1_manage_1_1_init_response.html#a1b1d7477b797163166b115615c440ed0", null ],
    [ "MacAddress", "class_p_o_s_link_admin_1_1_manage_1_1_init_response.html#adf5927cc66abe8ec8847423c235f01cf", null ],
    [ "ModelName", "class_p_o_s_link_admin_1_1_manage_1_1_init_response.html#a1e04f93922fe32132bc8322ddff3aa1d", null ],
    [ "OsVersion", "class_p_o_s_link_admin_1_1_manage_1_1_init_response.html#a6320e7b8f5bc112b6f2a15014c041fe5", null ],
    [ "ProtocolFlag", "class_p_o_s_link_admin_1_1_manage_1_1_init_response.html#a7bfd1fffe856522a6a4f69e04fca8988", null ],
    [ "Sn", "class_p_o_s_link_admin_1_1_manage_1_1_init_response.html#ae13805ebedfcee87fda4ab6aad136506", null ],
    [ "Touchscreen", "class_p_o_s_link_admin_1_1_manage_1_1_init_response.html#a1f65659993947eb1e182ad5395f0a1e9", null ],
    [ "WifiMac", "class_p_o_s_link_admin_1_1_manage_1_1_init_response.html#a22ae58a0908918a105d28d19108a0dd9", null ]
];