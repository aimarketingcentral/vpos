var class_p_o_s_link_admin_1_1_util_1_1_amount_request =
[
    [ "CashBackAmount", "class_p_o_s_link_admin_1_1_util_1_1_amount_request.html#a821b655f285a8258db32df653990ba76", null ],
    [ "FuelAmount", "class_p_o_s_link_admin_1_1_util_1_1_amount_request.html#a4d50a5aff4983286d87a69742b2a9452", null ],
    [ "MerchantFee", "class_p_o_s_link_admin_1_1_util_1_1_amount_request.html#a213bc0e2a5c86657ef50d9c2c9fff41f", null ],
    [ "OriginalAmount", "class_p_o_s_link_admin_1_1_util_1_1_amount_request.html#ae6ce74abbe01f2818aff9d58366e1400", null ],
    [ "ServiceFee", "class_p_o_s_link_admin_1_1_util_1_1_amount_request.html#a2f009ef71fca4a3612daa0df62d1ee59", null ],
    [ "TaxAmount", "class_p_o_s_link_admin_1_1_util_1_1_amount_request.html#aa4c6f2559f8d787f8ac19838f7dcc683", null ],
    [ "TipAmount", "class_p_o_s_link_admin_1_1_util_1_1_amount_request.html#a89ebc65a300701d70b68cac30f030516", null ],
    [ "TransactionAmount", "class_p_o_s_link_admin_1_1_util_1_1_amount_request.html#af3a4463651125ca4b69b2435087dd4f6", null ]
];