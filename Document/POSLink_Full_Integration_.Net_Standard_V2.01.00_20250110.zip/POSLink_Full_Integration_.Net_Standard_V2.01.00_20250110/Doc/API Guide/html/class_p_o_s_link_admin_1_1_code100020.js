var class_p_o_s_link_admin_1_1_code100020 =
[
    [ "CannotAdjust", "class_p_o_s_link_admin_1_1_code100020.html#aa77d48eeae3607d8080388fe3e5823aa", null ],
    [ "SwipeError", "class_p_o_s_link_admin_1_1_code100020.html#ada853553cec90385b422cfbe69783c5f", null ]
];