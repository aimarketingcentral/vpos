var class_p_o_s_link_admin_1_1_manage_1_1_set_google_smart_tap_parameters_request =
[
    [ "GoogleSmartTapData", "class_p_o_s_link_admin_1_1_manage_1_1_set_google_smart_tap_parameters_request.html#a8ddcedf3dc74715943c8b1da9080a37a", null ],
    [ "VasMode", "class_p_o_s_link_admin_1_1_manage_1_1_set_google_smart_tap_parameters_request.html#a6cd6c12156d9c2af233e0645e229ee95", null ]
];