var class_p_o_s_link_admin_1_1_device_1_1_camera_scan_response =
[
    [ "BarcodeData", "class_p_o_s_link_admin_1_1_device_1_1_camera_scan_response.html#a661f68054949e245c7bf021e2e34c021", null ],
    [ "BarcodeType", "class_p_o_s_link_admin_1_1_device_1_1_camera_scan_response.html#a905e59a0a193e1445c160e360d659e4e", null ]
];