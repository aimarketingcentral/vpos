var class_p_o_s_link_core_1_1_log_setting =
[
    [ "LogLevel", "class_p_o_s_link_core_1_1_log_setting.html#a6a9daedcf4c8b21ec687c07c9f52d7ec", [
      [ "Error", "class_p_o_s_link_core_1_1_log_setting.html#a6a9daedcf4c8b21ec687c07c9f52d7eca902b0d55fddef6f8d651fe1035b7d4bd", null ],
      [ "Debug", "class_p_o_s_link_core_1_1_log_setting.html#a6a9daedcf4c8b21ec687c07c9f52d7ecaa603905470e2a5b8c13e96b579ef0dba", null ]
    ] ],
    [ "LogSetting", "class_p_o_s_link_core_1_1_log_setting.html#abd5ad5965b0ffb322ea41626c121ef72", null ],
    [ "Days", "class_p_o_s_link_core_1_1_log_setting.html#af4fc05dad0bd1df8f5576707b33100d7", null ],
    [ "Enabled", "class_p_o_s_link_core_1_1_log_setting.html#afa71b6513e31f80cb184e5580802edf6", null ],
    [ "FileName", "class_p_o_s_link_core_1_1_log_setting.html#a6e847df2aa90b42b3cdf75c931120f57", null ],
    [ "FilePath", "class_p_o_s_link_core_1_1_log_setting.html#a65b362815f2cde693c395fc028b7fd9a", null ],
    [ "Level", "class_p_o_s_link_core_1_1_log_setting.html#aa3fe511709f2ef71fd864018c0d27daf", null ]
];