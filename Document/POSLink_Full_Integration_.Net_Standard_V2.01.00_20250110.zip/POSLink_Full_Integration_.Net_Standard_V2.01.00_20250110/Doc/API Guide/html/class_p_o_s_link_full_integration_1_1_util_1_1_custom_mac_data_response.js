var class_p_o_s_link_full_integration_1_1_util_1_1_custom_mac_data_response =
[
    [ "Data", "class_p_o_s_link_full_integration_1_1_util_1_1_custom_mac_data_response.html#af4350a98f4e74f948855f3b0f165e861", null ],
    [ "Ksn", "class_p_o_s_link_full_integration_1_1_util_1_1_custom_mac_data_response.html#a47a2e8b92e89db2924d08613621a3a95", null ]
];