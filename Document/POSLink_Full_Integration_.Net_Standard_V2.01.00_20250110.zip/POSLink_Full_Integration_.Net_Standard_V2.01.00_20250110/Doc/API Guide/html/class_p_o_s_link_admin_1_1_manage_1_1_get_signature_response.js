var class_p_o_s_link_admin_1_1_manage_1_1_get_signature_response =
[
    [ "SignatureData", "class_p_o_s_link_admin_1_1_manage_1_1_get_signature_response.html#aa6772c2c1e7b6aada3dc76299cc12eb1", null ]
];