var class_p_o_s_link_core_1_1_communication_setting_1_1_customer_communication_setting =
[
    [ "Close", "class_p_o_s_link_core_1_1_communication_setting_1_1_customer_communication_setting.html#add397814e14ca94841c6b4e91e075c41", null ],
    [ "IsSameCommunication", "class_p_o_s_link_core_1_1_communication_setting_1_1_customer_communication_setting.html#aae623fd21bce4d4b426bf6799e406dec", null ],
    [ "Open", "class_p_o_s_link_core_1_1_communication_setting_1_1_customer_communication_setting.html#a8143edc9eaaae1b1136455793234938c", null ],
    [ "Read", "class_p_o_s_link_core_1_1_communication_setting_1_1_customer_communication_setting.html#a804655cd20da3a1eb70d40a698964dd8", null ],
    [ "Write", "class_p_o_s_link_core_1_1_communication_setting_1_1_customer_communication_setting.html#afbb4c5b3a50c9165004eddac463e7917", null ],
    [ "Timeout", "class_p_o_s_link_core_1_1_communication_setting_1_1_customer_communication_setting.html#a5318b3511a47fe0fd341d96ce580e39a", null ]
];