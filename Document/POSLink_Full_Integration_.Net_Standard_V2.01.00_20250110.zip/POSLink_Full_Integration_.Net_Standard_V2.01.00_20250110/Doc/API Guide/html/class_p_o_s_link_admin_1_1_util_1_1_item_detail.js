var class_p_o_s_link_admin_1_1_util_1_1_item_detail =
[
    [ "PluCode", "class_p_o_s_link_admin_1_1_util_1_1_item_detail.html#a91b82df7f13355f9390ce4b5f175299e", null ],
    [ "Price", "class_p_o_s_link_admin_1_1_util_1_1_item_detail.html#afd90038fc67305ba1611bbbb8fb70a77", null ],
    [ "ProductImageDescription", "class_p_o_s_link_admin_1_1_util_1_1_item_detail.html#abc5327a09b03ba5860c138b20eb93eaf", null ],
    [ "ProductImageName", "class_p_o_s_link_admin_1_1_util_1_1_item_detail.html#a51540fd9c198bb459f5abe69afcb9400", null ],
    [ "ProductName", "class_p_o_s_link_admin_1_1_util_1_1_item_detail.html#a8ff9c4de7c32b18f663f6a290b5d42a2", null ],
    [ "Quantity", "class_p_o_s_link_admin_1_1_util_1_1_item_detail.html#ac1c2d6cebd49948a59086403f5564f2d", null ],
    [ "Tax", "class_p_o_s_link_admin_1_1_util_1_1_item_detail.html#adaff4bc5ae7dc0b8d9175376f475a21e", null ],
    [ "Unit", "class_p_o_s_link_admin_1_1_util_1_1_item_detail.html#a04fd879df63d85e399af754506627f19", null ],
    [ "UnitPrice", "class_p_o_s_link_admin_1_1_util_1_1_item_detail.html#abedb2b36923086d684924955c97b0e87", null ]
];