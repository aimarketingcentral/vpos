var class_p_o_s_link_full_integration_1_1_util_1_1_terminal_configuration =
[
    [ "CurrencyCode", "class_p_o_s_link_full_integration_1_1_util_1_1_terminal_configuration.html#aa27273e8fcb048a9c209431154ef5c73", null ],
    [ "CurrencyExponent", "class_p_o_s_link_full_integration_1_1_util_1_1_terminal_configuration.html#a277edfaec99be60fe2b4fed7b7e72ace", null ],
    [ "EmvKernelConfigurationSelection", "class_p_o_s_link_full_integration_1_1_util_1_1_terminal_configuration.html#a3ba26b77838f2faba75be8306954155b", null ],
    [ "MerchantCategoryCode", "class_p_o_s_link_full_integration_1_1_util_1_1_terminal_configuration.html#a6be1dd1b0cc58dcf328a4ab985077e0e", null ],
    [ "TransactionCvmLimit", "class_p_o_s_link_full_integration_1_1_util_1_1_terminal_configuration.html#a65d260d0834dfce80f40b8c1a63b1f8d", null ],
    [ "TransactionDate", "class_p_o_s_link_full_integration_1_1_util_1_1_terminal_configuration.html#a48a1830e93097a9848a4bef23396b9e2", null ],
    [ "TransactionSequenceNumber", "class_p_o_s_link_full_integration_1_1_util_1_1_terminal_configuration.html#af8bae5b13c97cbbafaa09845abbc6a48", null ],
    [ "TransactionTime", "class_p_o_s_link_full_integration_1_1_util_1_1_terminal_configuration.html#a96f1b71194970f7661b64f42b141e450", null ]
];