var class_p_o_s_link_full_integration_1_1_full_integration_1_1_set_emv_tlv_data_request =
[
    [ "EmvTlvData", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_set_emv_tlv_data_request.html#a374d833b80bd6dc022e16e67c5626f97", null ],
    [ "TlvType", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_set_emv_tlv_data_request.html#af060a1855e68d5cb4555e398eeff293c", null ]
];