var class_p_o_s_link_admin_1_1_ped_1_1_increase_ksn_response =
[
    [ "Ksn", "class_p_o_s_link_admin_1_1_ped_1_1_increase_ksn_response.html#a25493c9f66c9e41568504352d36cd53c", null ]
];