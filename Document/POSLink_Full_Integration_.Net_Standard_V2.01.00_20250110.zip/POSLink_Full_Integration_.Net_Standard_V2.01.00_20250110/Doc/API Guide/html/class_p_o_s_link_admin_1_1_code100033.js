var class_p_o_s_link_admin_1_1_code100033 =
[
    [ "ManualEntryDisabled", "class_p_o_s_link_admin_1_1_code100033.html#adcd458cf6ede33aeb6b25b609525e82c", null ],
    [ "SwipeEntryDisabled", "class_p_o_s_link_admin_1_1_code100033.html#a7dd4d05cfe946b4e7c8b534404f5ad85", null ]
];