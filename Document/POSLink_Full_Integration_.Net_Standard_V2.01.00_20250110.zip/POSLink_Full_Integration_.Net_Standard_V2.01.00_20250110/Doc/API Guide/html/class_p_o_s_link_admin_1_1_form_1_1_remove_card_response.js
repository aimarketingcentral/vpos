var class_p_o_s_link_admin_1_1_form_1_1_remove_card_response =
[
    [ "PinpadType", "class_p_o_s_link_admin_1_1_form_1_1_remove_card_response.html#ae5ee451c9bb39336ccc2a72531639d62", null ]
];