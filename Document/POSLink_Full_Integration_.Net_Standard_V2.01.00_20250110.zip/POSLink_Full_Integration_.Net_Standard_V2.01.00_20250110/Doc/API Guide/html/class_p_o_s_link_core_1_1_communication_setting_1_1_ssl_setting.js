var class_p_o_s_link_core_1_1_communication_setting_1_1_ssl_setting =
[
    [ "SslSetting", "class_p_o_s_link_core_1_1_communication_setting_1_1_ssl_setting.html#a2d6ca35e1fb05695c6cda8e09270b466", null ],
    [ "SslSetting", "class_p_o_s_link_core_1_1_communication_setting_1_1_ssl_setting.html#a2f626092ddb1303cc6f32de6201f1cd0", null ],
    [ "Ip", "class_p_o_s_link_core_1_1_communication_setting_1_1_ssl_setting.html#a3a12666b6761815184d13a5e88acc036", null ],
    [ "Port", "class_p_o_s_link_core_1_1_communication_setting_1_1_ssl_setting.html#a4a5cf1388c776cbdbeefa04c32fd8a18", null ],
    [ "Timeout", "class_p_o_s_link_core_1_1_communication_setting_1_1_ssl_setting.html#a03484c2c85670f1a4c9d7deef1d732af", null ]
];