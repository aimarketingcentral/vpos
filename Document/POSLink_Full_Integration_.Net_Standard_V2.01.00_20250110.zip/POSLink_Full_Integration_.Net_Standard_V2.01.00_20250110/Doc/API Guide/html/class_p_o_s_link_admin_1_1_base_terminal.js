var class_p_o_s_link_admin_1_1_base_terminal =
[
    [ "Cancel", "class_p_o_s_link_admin_1_1_base_terminal.html#a111f834b45a0657189d02a473ffc4315", null ],
    [ "GetReportStatus", "class_p_o_s_link_admin_1_1_base_terminal.html#a96ee211ee358b99abab55bf11241e20f", null ],
    [ "UploadLog", "class_p_o_s_link_admin_1_1_base_terminal.html#a928cb0bb155b66437aa4117b407d49d8", null ],
    [ "Device", "class_p_o_s_link_admin_1_1_base_terminal.html#a6ecb3532bc5dc8f59d32d6fbe6dfcd32", null ],
    [ "Form", "class_p_o_s_link_admin_1_1_base_terminal.html#a4ffc864f81e6e9aaab17c0704c0b47b0", null ],
    [ "Manage", "class_p_o_s_link_admin_1_1_base_terminal.html#ab4c2c39d1c14834591384ef3f62c5e98", null ],
    [ "Payload", "class_p_o_s_link_admin_1_1_base_terminal.html#ac3205a4bd104bd8278ca6af58ad52923", null ],
    [ "Ped", "class_p_o_s_link_admin_1_1_base_terminal.html#a8c76ede0be85eed00a74a24fe131a750", null ]
];