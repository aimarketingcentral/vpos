var class_p_o_s_link_admin_1_1_form_1_1_show_message_center_request =
[
    [ "IconName", "class_p_o_s_link_admin_1_1_form_1_1_show_message_center_request.html#a765433a6dc486de7388d621ea500832a", null ],
    [ "Message1", "class_p_o_s_link_admin_1_1_form_1_1_show_message_center_request.html#a1a1c0a93a7097e2c824b6b423940ba82", null ],
    [ "Message2", "class_p_o_s_link_admin_1_1_form_1_1_show_message_center_request.html#a574b3b7ac329eefa6623189333a7b033", null ],
    [ "PinpadType", "class_p_o_s_link_admin_1_1_form_1_1_show_message_center_request.html#a88a3a2fdc4e8e508644c335dbffddc58", null ],
    [ "Timeout", "class_p_o_s_link_admin_1_1_form_1_1_show_message_center_request.html#ad4f27aeee0c1c20b4d34dac3c81b62e0", null ],
    [ "Title", "class_p_o_s_link_admin_1_1_form_1_1_show_message_center_request.html#a226e8822669c88bfcb4179b26f01744d", null ]
];