var class_p_o_s_link_admin_1_1_manage_1_1_apple_pay_vas =
[
    [ "KeyFileMapping", "class_p_o_s_link_admin_1_1_manage_1_1_apple_pay_vas.html#a230c3453e01c3cf3a08e20e84d49700c", null ],
    [ "MerchantId", "class_p_o_s_link_admin_1_1_manage_1_1_apple_pay_vas.html#ab21901d3417f0ee70faebf59efc673ca", null ],
    [ "Url", "class_p_o_s_link_admin_1_1_manage_1_1_apple_pay_vas.html#a8ceee3f3433118204a40e4b2ef15b358", null ],
    [ "UrlMode", "class_p_o_s_link_admin_1_1_manage_1_1_apple_pay_vas.html#a77dc30782d19e9ef9ed607c091907940", null ]
];