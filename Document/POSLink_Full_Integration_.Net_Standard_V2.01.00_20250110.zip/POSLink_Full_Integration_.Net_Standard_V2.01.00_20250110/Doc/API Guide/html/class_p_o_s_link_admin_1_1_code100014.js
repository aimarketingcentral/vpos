var class_p_o_s_link_admin_1_1_code100014 =
[
    [ "InvalidDataEntry", "class_p_o_s_link_admin_1_1_code100014.html#af552f267bc7a92c27af4b7977f550e9e", null ],
    [ "InvalidVarValue", "class_p_o_s_link_admin_1_1_code100014.html#a879d90f7c60a094dc909216730ef1e93", null ],
    [ "PleaseSetVar", "class_p_o_s_link_admin_1_1_code100014.html#a8d5fc3674095bbb7d3e6a5da9b2eb0ba", null ],
    [ "SetVarError", "class_p_o_s_link_admin_1_1_code100014.html#a6d8d47eb0203a945a4f43402d6622d36", null ]
];