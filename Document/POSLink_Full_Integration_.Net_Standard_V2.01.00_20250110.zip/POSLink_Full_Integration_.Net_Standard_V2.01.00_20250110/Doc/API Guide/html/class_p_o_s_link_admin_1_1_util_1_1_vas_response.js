var class_p_o_s_link_admin_1_1_util_1_1_vas_response =
[
    [ "NdefData", "class_p_o_s_link_admin_1_1_util_1_1_vas_response.html#ae7a86010d1e43a4fe08895d863d2a54b", null ],
    [ "VasCode", "class_p_o_s_link_admin_1_1_util_1_1_vas_response.html#a2ca7205497951cf6727507c2b6ce6d43", null ],
    [ "VasData", "class_p_o_s_link_admin_1_1_util_1_1_vas_response.html#a84e624bb074a7376d1680f6ac4b6c133", null ]
];