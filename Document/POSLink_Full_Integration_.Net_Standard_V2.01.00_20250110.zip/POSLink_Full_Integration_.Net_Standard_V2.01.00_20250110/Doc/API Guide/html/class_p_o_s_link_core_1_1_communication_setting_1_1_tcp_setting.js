var class_p_o_s_link_core_1_1_communication_setting_1_1_tcp_setting =
[
    [ "TcpSetting", "class_p_o_s_link_core_1_1_communication_setting_1_1_tcp_setting.html#a1b1340e8df150feb117e3b9d6c26053d", null ],
    [ "TcpSetting", "class_p_o_s_link_core_1_1_communication_setting_1_1_tcp_setting.html#aaf49cbda03ef6d94b1968a2c53c925a4", null ],
    [ "Ip", "class_p_o_s_link_core_1_1_communication_setting_1_1_tcp_setting.html#a4689310fadb54ca990689eabf8e2aa55", null ],
    [ "Port", "class_p_o_s_link_core_1_1_communication_setting_1_1_tcp_setting.html#af7b13cc040fcad4547c33de72c149ea0", null ],
    [ "Timeout", "class_p_o_s_link_core_1_1_communication_setting_1_1_tcp_setting.html#a7ee9967c4adfbdeb1df1a073b3379ab9", null ]
];