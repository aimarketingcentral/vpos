var class_p_o_s_link_admin_1_1_device_1_1_device =
[
    [ "Camera", "class_p_o_s_link_admin_1_1_device_1_1_device.html#a9229f7f3f4d396bc3d1c8702af2bd70a", null ],
    [ "Card", "class_p_o_s_link_admin_1_1_device_1_1_device.html#a2f00814e52631e9d1a3a1b7ce9785465", null ],
    [ "MifareCard", "class_p_o_s_link_admin_1_1_device_1_1_device.html#ab8f228574a77ea568d070d8c073e5a3e", null ],
    [ "Printer", "class_p_o_s_link_admin_1_1_device_1_1_device.html#acfd2f9ffe55e6271af80e60a830cce40", null ]
];