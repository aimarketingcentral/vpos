var class_p_o_s_link_core_1_1_communication_setting_1_1_https_setting =
[
    [ "HttpsSetting", "class_p_o_s_link_core_1_1_communication_setting_1_1_https_setting.html#a18b0e4f3fe7b2f46a05789c5ea801364", null ],
    [ "HttpsSetting", "class_p_o_s_link_core_1_1_communication_setting_1_1_https_setting.html#ac9a4f3d16a2230b852ad75fbc04f9c80", null ],
    [ "Ip", "class_p_o_s_link_core_1_1_communication_setting_1_1_https_setting.html#a826e56c317a44776f2a43deb0c8bf80b", null ],
    [ "Port", "class_p_o_s_link_core_1_1_communication_setting_1_1_https_setting.html#abde7246b3a2e849c234b64ff047e84d5", null ],
    [ "Timeout", "class_p_o_s_link_core_1_1_communication_setting_1_1_https_setting.html#a8e66f0c2554fcfd42e474b9212b2dac6", null ]
];