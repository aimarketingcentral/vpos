var class_p_o_s_link_admin_1_1_code100021 =
[
    [ "AlreadyCompleted", "class_p_o_s_link_admin_1_1_code100021.html#a47e2c118ea58d53f8b7cf1d52dfb3582", null ],
    [ "AlreadyVoided", "class_p_o_s_link_admin_1_1_code100021.html#af484348b91754d914c694a7c90eb1192", null ]
];