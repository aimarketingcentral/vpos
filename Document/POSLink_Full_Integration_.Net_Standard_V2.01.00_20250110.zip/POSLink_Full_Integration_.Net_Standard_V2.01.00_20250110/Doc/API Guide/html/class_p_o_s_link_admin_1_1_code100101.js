var class_p_o_s_link_admin_1_1_code100101 =
[
    [ "HostReceiveError", "class_p_o_s_link_admin_1_1_code100101.html#a52d803bd1ebf73f42bed70dcf1e9d7d7", null ],
    [ "HostVarNameNotSet", "class_p_o_s_link_admin_1_1_code100101.html#a3fbbf5692da134ca5974f644848f6f95", null ]
];