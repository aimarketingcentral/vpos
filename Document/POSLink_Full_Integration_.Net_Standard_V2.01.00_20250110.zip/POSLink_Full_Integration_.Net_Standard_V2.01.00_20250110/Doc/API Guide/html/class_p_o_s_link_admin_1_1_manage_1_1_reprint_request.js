var class_p_o_s_link_admin_1_1_manage_1_1_reprint_request =
[
    [ "AuthorizationCode", "class_p_o_s_link_admin_1_1_manage_1_1_reprint_request.html#ac2fa72c8ea8ddf68ce9974de601e40a8", null ],
    [ "EcrReferenceNumber", "class_p_o_s_link_admin_1_1_manage_1_1_reprint_request.html#acfff4a69c825e18e6698d19616055825", null ],
    [ "EdcType", "class_p_o_s_link_admin_1_1_manage_1_1_reprint_request.html#af1bbeef84dfe0fa86dc516c00facd305", null ],
    [ "OriginalReferenceNumber", "class_p_o_s_link_admin_1_1_manage_1_1_reprint_request.html#ab82bbfabfc6d50600612a595548190ee", null ],
    [ "PrintLastReceipt", "class_p_o_s_link_admin_1_1_manage_1_1_reprint_request.html#a16d2ade6661dfb78181cb41c7604b023", null ],
    [ "ReceiptPrintFlag", "class_p_o_s_link_admin_1_1_manage_1_1_reprint_request.html#a1a3f2764183664d1950a5983516058d3", null ]
];