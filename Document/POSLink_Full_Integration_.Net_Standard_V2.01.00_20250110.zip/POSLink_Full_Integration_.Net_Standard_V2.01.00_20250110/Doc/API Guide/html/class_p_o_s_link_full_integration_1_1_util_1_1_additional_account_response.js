var class_p_o_s_link_full_integration_1_1_util_1_1_additional_account_response =
[
    [ "CardHolderName", "class_p_o_s_link_full_integration_1_1_util_1_1_additional_account_response.html#ab216b2018af204b9e72f7cc4a81a0b9f", null ],
    [ "CvvCode", "class_p_o_s_link_full_integration_1_1_util_1_1_additional_account_response.html#aa0e4c1eefb58fc4c791cedc99900758d", null ],
    [ "ExpiryDate", "class_p_o_s_link_full_integration_1_1_util_1_1_additional_account_response.html#aa4fb47fe0be378c01e55722f3b2c0785", null ],
    [ "ServiceCode", "class_p_o_s_link_full_integration_1_1_util_1_1_additional_account_response.html#adb1efcb1c76548794cdea957b50ac763", null ],
    [ "ZipCode", "class_p_o_s_link_full_integration_1_1_util_1_1_additional_account_response.html#ae2d0c3115c61e4b9248b5228362d28c4", null ]
];