var class_p_o_s_link_admin_1_1_ped_1_1_increase_ksn_request =
[
    [ "KeySlot", "class_p_o_s_link_admin_1_1_ped_1_1_increase_ksn_request.html#a97c241e94fbf5bda8e37f6c42e3e3233", null ],
    [ "KeyType", "class_p_o_s_link_admin_1_1_ped_1_1_increase_ksn_request.html#abcfdda39e598cdd7d6c18719067ef2bf", null ]
];