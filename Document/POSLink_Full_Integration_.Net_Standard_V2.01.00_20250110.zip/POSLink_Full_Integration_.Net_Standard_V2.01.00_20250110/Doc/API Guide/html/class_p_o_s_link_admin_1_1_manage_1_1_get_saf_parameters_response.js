var class_p_o_s_link_admin_1_1_manage_1_1_get_saf_parameters_response =
[
    [ "AutoUploadIntervalTime", "class_p_o_s_link_admin_1_1_manage_1_1_get_saf_parameters_response.html#a7fa822643a1a9da3d4f69d35c51223cb", null ],
    [ "CeilingAmountPerCardType", "class_p_o_s_link_admin_1_1_manage_1_1_get_saf_parameters_response.html#ace2fdc2b32f2a883892c655a9f7c7805", null ],
    [ "DeleteSafConfirmation", "class_p_o_s_link_admin_1_1_manage_1_1_get_saf_parameters_response.html#a01d8ed611056fbe53810845858c6177f", null ],
    [ "HaloPerCardType", "class_p_o_s_link_admin_1_1_manage_1_1_get_saf_parameters_response.html#ab9212d5809cc99412c1834fad46a1299", null ],
    [ "MaxNumber", "class_p_o_s_link_admin_1_1_manage_1_1_get_saf_parameters_response.html#ad129192ca66a9c3bdb88e6924e6d11c4", null ],
    [ "OfflineInformation", "class_p_o_s_link_admin_1_1_manage_1_1_get_saf_parameters_response.html#a64dd991078d9d1d6ace495b4b9ef76d3", null ],
    [ "SafMode", "class_p_o_s_link_admin_1_1_manage_1_1_get_saf_parameters_response.html#a453134a76f8bf7415e83303e01602a61", null ],
    [ "SafUploadIndicator", "class_p_o_s_link_admin_1_1_manage_1_1_get_saf_parameters_response.html#a80da613e74b223b3238ff8d93bc7406e", null ],
    [ "TotalCeilingAmount", "class_p_o_s_link_admin_1_1_manage_1_1_get_saf_parameters_response.html#a5421455c95b3e9eb9ed4c24c763b46a4", null ],
    [ "UploadMode", "class_p_o_s_link_admin_1_1_manage_1_1_get_saf_parameters_response.html#ae77dface097c33053f8495449354c06e", null ]
];