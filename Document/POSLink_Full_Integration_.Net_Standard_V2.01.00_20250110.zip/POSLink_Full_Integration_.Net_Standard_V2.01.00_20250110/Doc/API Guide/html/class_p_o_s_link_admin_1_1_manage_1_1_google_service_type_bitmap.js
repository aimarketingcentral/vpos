var class_p_o_s_link_admin_1_1_manage_1_1_google_service_type_bitmap =
[
    [ "AllServices", "class_p_o_s_link_admin_1_1_manage_1_1_google_service_type_bitmap.html#a4ae0952dafc5f37e41428d13c8cc2897", null ],
    [ "AllServicesExceptPpse", "class_p_o_s_link_admin_1_1_manage_1_1_google_service_type_bitmap.html#a52dc5be4ff9ae4ff6a9b17115b4b5f9d", null ],
    [ "CloudBasedWallet", "class_p_o_s_link_admin_1_1_manage_1_1_google_service_type_bitmap.html#af75af1388f87d89acf2dce265209d842", null ],
    [ "GiftCard1", "class_p_o_s_link_admin_1_1_manage_1_1_google_service_type_bitmap.html#a61ac28573627468915b5a085cbde0d97", null ],
    [ "Loyalty", "class_p_o_s_link_admin_1_1_manage_1_1_google_service_type_bitmap.html#a34b930992f1c1e73a0c90f418bca8c51", null ],
    [ "MobileMarketingPlatform", "class_p_o_s_link_admin_1_1_manage_1_1_google_service_type_bitmap.html#a6c8350227338960e555592d0704eeb65", null ],
    [ "Offer", "class_p_o_s_link_admin_1_1_manage_1_1_google_service_type_bitmap.html#ad1d7c479215093464c353f8c199281fb", null ],
    [ "Ppse", "class_p_o_s_link_admin_1_1_manage_1_1_google_service_type_bitmap.html#a6c47bb4c656d3e1117c2e6a6b6c89710", null ],
    [ "PrivateLabelCard", "class_p_o_s_link_admin_1_1_manage_1_1_google_service_type_bitmap.html#a9f6dfbb6dcbbce7b72ada52d2b19011f", null ],
    [ "WalletCustomer", "class_p_o_s_link_admin_1_1_manage_1_1_google_service_type_bitmap.html#a12bbddd50a241d91ac56755fdc9fff7e", null ]
];