var class_p_o_s_link_admin_1_1_util_1_1_offline_information_response =
[
    [ "DurationOfflineInDays", "class_p_o_s_link_admin_1_1_util_1_1_offline_information_response.html#a602ad25fcc532fc25adcf924d4af837a", null ],
    [ "EndOfflineDateTime", "class_p_o_s_link_admin_1_1_util_1_1_offline_information_response.html#ad453e8559a46d502e99e6979fd365582", null ],
    [ "StartOfflineDateTime", "class_p_o_s_link_admin_1_1_util_1_1_offline_information_response.html#a97d427ac02c5b24b8a9b5265cd198d4c", null ]
];