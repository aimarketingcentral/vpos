var class_p_o_s_link_admin_1_1_device_1_1_mifare_card =
[
    [ "Operate", "class_p_o_s_link_admin_1_1_device_1_1_mifare_card.html#afb426d796b36eaef738c30c353832f49", null ]
];