var class_p_o_s_link_admin_1_1_response =
[
    [ "ResponseCode", "class_p_o_s_link_admin_1_1_response.html#ae43b4904993e8e11f7a3327577ba92fa", null ],
    [ "ResponseMessage", "class_p_o_s_link_admin_1_1_response.html#a50be8681ffc2c7b57c2d7dbce02707c4", null ]
];