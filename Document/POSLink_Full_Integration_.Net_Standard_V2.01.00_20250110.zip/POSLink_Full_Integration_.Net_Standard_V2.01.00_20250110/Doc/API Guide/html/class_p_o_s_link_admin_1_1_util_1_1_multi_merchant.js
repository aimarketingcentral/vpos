var class_p_o_s_link_admin_1_1_util_1_1_multi_merchant =
[
    [ "MultiMerchantId", "class_p_o_s_link_admin_1_1_util_1_1_multi_merchant.html#af4a9d204664fab2d199538e22dda3dd6", null ],
    [ "MultiMerchantName", "class_p_o_s_link_admin_1_1_util_1_1_multi_merchant.html#a2dcbe9d46915b6e003e6a0a840a685a7", null ]
];