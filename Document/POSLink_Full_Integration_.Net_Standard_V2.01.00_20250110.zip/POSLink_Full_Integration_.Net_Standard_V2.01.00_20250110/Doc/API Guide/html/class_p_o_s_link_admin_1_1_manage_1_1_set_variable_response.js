var class_p_o_s_link_admin_1_1_manage_1_1_set_variable_response =
[
    [ "MultiMerchant", "class_p_o_s_link_admin_1_1_manage_1_1_set_variable_response.html#a053f4ad2c1005be1deb0c4dc10ddb6ba", null ]
];