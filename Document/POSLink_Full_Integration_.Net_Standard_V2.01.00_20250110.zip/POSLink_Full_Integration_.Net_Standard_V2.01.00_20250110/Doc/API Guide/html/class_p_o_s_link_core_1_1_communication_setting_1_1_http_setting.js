var class_p_o_s_link_core_1_1_communication_setting_1_1_http_setting =
[
    [ "HttpSetting", "class_p_o_s_link_core_1_1_communication_setting_1_1_http_setting.html#a8f3398701b86bf508e2ab0594216b502", null ],
    [ "HttpSetting", "class_p_o_s_link_core_1_1_communication_setting_1_1_http_setting.html#a974b30e66c837c92a07a1766a7ba7a23", null ],
    [ "Ip", "class_p_o_s_link_core_1_1_communication_setting_1_1_http_setting.html#afbdbacd8eb3d8c133b3bb7ed47e9a0cf", null ],
    [ "Port", "class_p_o_s_link_core_1_1_communication_setting_1_1_http_setting.html#afdf598145c6e032d1a940e8033372e94", null ],
    [ "Timeout", "class_p_o_s_link_core_1_1_communication_setting_1_1_http_setting.html#a7107deed26bddbe9fc101f0b4b8f86c7", null ]
];