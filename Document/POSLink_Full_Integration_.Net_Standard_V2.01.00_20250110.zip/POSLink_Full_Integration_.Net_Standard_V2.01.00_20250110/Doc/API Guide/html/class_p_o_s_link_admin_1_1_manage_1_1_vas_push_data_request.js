var class_p_o_s_link_admin_1_1_manage_1_1_vas_push_data_request =
[
    [ "GoogleSmartTapPushService", "class_p_o_s_link_admin_1_1_manage_1_1_vas_push_data_request.html#ab3fc8a44c280d67aa877e3f870377585", null ],
    [ "VasMode", "class_p_o_s_link_admin_1_1_manage_1_1_vas_push_data_request.html#a318dcb7dfa67f7c1bb54c845458aaa6c", null ]
];