var class_p_o_s_link_admin_1_1_code100004 =
[
    [ "UnsupportOriginalTransactionType", "class_p_o_s_link_admin_1_1_code100004.html#a0c6987d8c9f58aef0029b6614a24e652", null ],
    [ "UnsupportTransaction", "class_p_o_s_link_admin_1_1_code100004.html#a137bf359ba747ef50d2bddba42e8285c", null ],
    [ "UnsupportTransactionType", "class_p_o_s_link_admin_1_1_code100004.html#aa3068f753ec2cd154d6d0c6bbc37f0b4", null ]
];