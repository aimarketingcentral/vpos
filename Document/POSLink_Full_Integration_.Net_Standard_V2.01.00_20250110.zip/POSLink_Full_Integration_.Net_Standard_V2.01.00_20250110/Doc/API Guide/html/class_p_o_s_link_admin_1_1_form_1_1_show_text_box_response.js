var class_p_o_s_link_admin_1_1_form_1_1_show_text_box_response =
[
    [ "ButtonNumber", "class_p_o_s_link_admin_1_1_form_1_1_show_text_box_response.html#ace4876d5451a9f7b34bda262e5fbc6f0", null ],
    [ "SignatureData", "class_p_o_s_link_admin_1_1_form_1_1_show_text_box_response.html#ac56ef9110167a7614ac327c034b38e3b", null ],
    [ "SignStatus", "class_p_o_s_link_admin_1_1_form_1_1_show_text_box_response.html#a5118046287249c462e737daaf5d1e306", null ],
    [ "Text", "class_p_o_s_link_admin_1_1_form_1_1_show_text_box_response.html#a33cb9d3d78edc70a958d02191d5ca265", null ]
];