var class_p_o_s_link_admin_1_1_manage_1_1_set_saf_parameters_request =
[
    [ "AutoUploadIntervalTime", "class_p_o_s_link_admin_1_1_manage_1_1_set_saf_parameters_request.html#af3c36ff3415c81cc02c49a36a43b2ea9", null ],
    [ "CeilingAmountPerCardType", "class_p_o_s_link_admin_1_1_manage_1_1_set_saf_parameters_request.html#a92ce3e0eca425dbe9f0fb70d1a9fea01", null ],
    [ "DeleteSafConfirmation", "class_p_o_s_link_admin_1_1_manage_1_1_set_saf_parameters_request.html#ad773fa86beb2cce98b31a6128d1843c7", null ],
    [ "HaloPerCardType", "class_p_o_s_link_admin_1_1_manage_1_1_set_saf_parameters_request.html#a10d6a5516e393b9cb12896358e3a7280", null ],
    [ "MaxNumber", "class_p_o_s_link_admin_1_1_manage_1_1_set_saf_parameters_request.html#a7c814e1a7c682d8d060beaa14fe2360e", null ],
    [ "OfflineInformation", "class_p_o_s_link_admin_1_1_manage_1_1_set_saf_parameters_request.html#a9bbec5f176fae5bb49995bddfb0f6dd6", null ],
    [ "SafMode", "class_p_o_s_link_admin_1_1_manage_1_1_set_saf_parameters_request.html#a54e84954035cdaa94c3c7ea063aba80b", null ],
    [ "SafUploadIndicator", "class_p_o_s_link_admin_1_1_manage_1_1_set_saf_parameters_request.html#ab6853d90de1477e0da2a5c28057ad8cc", null ],
    [ "TotalCeilingAmount", "class_p_o_s_link_admin_1_1_manage_1_1_set_saf_parameters_request.html#a67f7b53c2e3b2cd32c9418481eed92cc", null ],
    [ "UploadMode", "class_p_o_s_link_admin_1_1_manage_1_1_set_saf_parameters_request.html#a316c933a99826b363003257a433fb311", null ]
];