var class_p_o_s_link_admin_1_1_manage_1_1_get_variable_request =
[
    [ "EdcType", "class_p_o_s_link_admin_1_1_manage_1_1_get_variable_request.html#af5f2f6e46a8a5ed3c32633260b719fe4", null ],
    [ "MultiMerchant", "class_p_o_s_link_admin_1_1_manage_1_1_get_variable_request.html#a6a58d2fc6fd24592fe2f454753f702be", null ],
    [ "VariableName1", "class_p_o_s_link_admin_1_1_manage_1_1_get_variable_request.html#a611b3abc861947769e6c88ecc801f3e9", null ],
    [ "VariableName2", "class_p_o_s_link_admin_1_1_manage_1_1_get_variable_request.html#a41bb281f95f369f5f8b738203585ed85", null ],
    [ "VariableName3", "class_p_o_s_link_admin_1_1_manage_1_1_get_variable_request.html#a15b0ce8a1f6e799ec3a70fc690ee29b6", null ],
    [ "VariableName4", "class_p_o_s_link_admin_1_1_manage_1_1_get_variable_request.html#aff42ed306891efd35ef4f97b87d374a4", null ],
    [ "VariableName5", "class_p_o_s_link_admin_1_1_manage_1_1_get_variable_request.html#a5c25e513fa7436aa82f96390d9ea825f", null ]
];