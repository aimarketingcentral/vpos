var class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_request =
[
    [ "AccountNumber", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_request.html#a301b85096222e5adf4de00677356c18f", null ],
    [ "AllowOnlinePinBypass", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_request.html#ad41f7cc57ecacaeba3551f63a016ac4a", null ],
    [ "EdcType", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_request.html#a98989017cc3e05c7d59e7f7e9e2fe186", null ],
    [ "EncryptionType", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_request.html#affafb149448378e2ac03a2da0ae4758a", null ],
    [ "KeySlot", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_request.html#a48ff4443af56ac78b7abe8d11d9412ea", null ],
    [ "KsnFlag", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_request.html#a330af381c00eaf653cba163686c585b2", null ],
    [ "PinAlgorithm", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_request.html#aad9c837a15987be4d5db625f25987ba3", null ],
    [ "PinMaxLength", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_request.html#a4049a7f8edea130e67460fc7e35fc1cb", null ],
    [ "PinMinLength", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_request.html#afdae4d57b63272851d198363bc5c35e6", null ],
    [ "PinpadType", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_request.html#a2d97b02b7b036ff7e28593ec24f3ca9e", null ],
    [ "Timeout", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_request.html#af160e05780c0cd9069246aa03e530e4b", null ],
    [ "Title", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_request.html#aaa71dfbba1c899bef9ec98a772b6e6e1", null ],
    [ "TransactionType", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_request.html#a6d9d83bf09302d05c413b9aadd0cbbec", null ]
];