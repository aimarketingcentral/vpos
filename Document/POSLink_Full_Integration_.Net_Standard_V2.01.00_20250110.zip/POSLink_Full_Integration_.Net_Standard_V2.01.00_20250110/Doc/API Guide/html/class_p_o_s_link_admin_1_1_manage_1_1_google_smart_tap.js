var class_p_o_s_link_admin_1_1_manage_1_1_google_smart_tap =
[
    [ "CollectId", "class_p_o_s_link_admin_1_1_manage_1_1_google_smart_tap.html#a16f67c340ee5f66cecb0bb75742de768", null ],
    [ "EndTap", "class_p_o_s_link_admin_1_1_manage_1_1_google_smart_tap.html#a8e0ece4ea776edf2edf79b02309392f6", null ],
    [ "GoogleSmartTapCap", "class_p_o_s_link_admin_1_1_manage_1_1_google_smart_tap.html#afc7b4ea5eb96732391ccbec19f9fb15d", null ],
    [ "MerchantCategory", "class_p_o_s_link_admin_1_1_manage_1_1_google_smart_tap.html#a32ab679561cc2d18fdd2010d3e1df863", null ],
    [ "MerchantName", "class_p_o_s_link_admin_1_1_manage_1_1_google_smart_tap.html#a1dd61239b4176ceb276a771925eb65b7", null ],
    [ "OseToPpse", "class_p_o_s_link_admin_1_1_manage_1_1_google_smart_tap.html#a2713c91feeb10db131bb62182927438d", null ],
    [ "Security", "class_p_o_s_link_admin_1_1_manage_1_1_google_smart_tap.html#a32f480066263ab43ec438b23191a4609", null ],
    [ "ServiceType", "class_p_o_s_link_admin_1_1_manage_1_1_google_smart_tap.html#a818bfab0204dea70150efcfa6e4081e9", null ],
    [ "StoreLocalId", "class_p_o_s_link_admin_1_1_manage_1_1_google_smart_tap.html#ae3967cd2268b7bdccc0a982e7e21063e", null ],
    [ "TerminalId", "class_p_o_s_link_admin_1_1_manage_1_1_google_smart_tap.html#a92113ab82946ef6191df4ea315258788", null ]
];