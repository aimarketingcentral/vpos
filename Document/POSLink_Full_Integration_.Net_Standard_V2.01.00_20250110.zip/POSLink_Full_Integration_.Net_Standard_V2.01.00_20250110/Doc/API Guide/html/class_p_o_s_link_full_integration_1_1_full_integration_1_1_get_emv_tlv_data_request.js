var class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_emv_tlv_data_request =
[
    [ "TagList", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_emv_tlv_data_request.html#ad2d744d6722b9af430e37deb1e30c797", null ],
    [ "TlvType", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_emv_tlv_data_request.html#a0dca15fda5a286eb96ab4ae58b99fe4f", null ]
];