var class_p_o_s_link_full_integration_1_1_p_o_s_link_full =
[
    [ "POSLinkFull", "class_p_o_s_link_full_integration_1_1_p_o_s_link_full.html#a6be52db66eb3f2481833a14fd8b9d895", null ],
    [ "GetLogSetting", "class_p_o_s_link_full_integration_1_1_p_o_s_link_full.html#a1eaf046ecaac0d85772d59223836896e", null ],
    [ "GetPOSLinkFull", "class_p_o_s_link_full_integration_1_1_p_o_s_link_full.html#a4129ae7aff00432bd1b377672764d7d3", null ],
    [ "GetTerminal", "class_p_o_s_link_full_integration_1_1_p_o_s_link_full.html#a05e930d941ec8218cd37e9e1b7c01e7f", null ],
    [ "RemoveTerminal", "class_p_o_s_link_full_integration_1_1_p_o_s_link_full.html#a396fbdd24077b6a4bf6d9af18b911320", null ],
    [ "SetLogSetting", "class_p_o_s_link_full_integration_1_1_p_o_s_link_full.html#a81b284350ab5a6a37789bdb29dbaf81d", null ]
];