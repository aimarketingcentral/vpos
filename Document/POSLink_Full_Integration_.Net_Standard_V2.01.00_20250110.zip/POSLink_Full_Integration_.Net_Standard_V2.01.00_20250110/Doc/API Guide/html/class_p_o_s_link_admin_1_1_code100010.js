var class_p_o_s_link_admin_1_1_code100010 =
[
    [ "CommError", "class_p_o_s_link_admin_1_1_code100010.html#a8bfc669b3f286aa315294e09ba13b524", null ],
    [ "TerminalOfflinePinNotAvailable", "class_p_o_s_link_admin_1_1_code100010.html#a49811929750eb956f70649e8a89b7c26", null ]
];