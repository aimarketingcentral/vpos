var class_p_o_s_link_admin_1_1_code100023 =
[
    [ "CannotReversal", "class_p_o_s_link_admin_1_1_code100023.html#a538cf71839a17f5d6be1c1693dc63518", null ],
    [ "CannotVoid", "class_p_o_s_link_admin_1_1_code100023.html#af28b0cc72c2b17932c8c705decb883c4", null ],
    [ "DeleteTransactionFailed", "class_p_o_s_link_admin_1_1_code100023.html#ae38de2704ba321f0d1bd56363babdf12", null ],
    [ "MultipleRecordsFound", "class_p_o_s_link_admin_1_1_code100023.html#aebe95bca7368d493361262017b8ec3a5", null ],
    [ "NotFound", "class_p_o_s_link_admin_1_1_code100023.html#a4e64caf8b70c4d56fb8aa0274bbafb0b", null ],
    [ "UnknownError", "class_p_o_s_link_admin_1_1_code100023.html#ac56745a372244f70ce2006411ffafcba", null ],
    [ "UserAborted", "class_p_o_s_link_admin_1_1_code100023.html#ad43560225b7fd91c496bf678efe19817", null ]
];