var class_p_o_s_link_admin_1_1_device_1_1_printer_request =
[
    [ "PrintCopy", "class_p_o_s_link_admin_1_1_device_1_1_printer_request.html#a2691041e85a531f4eb5cfc447cd346e6", null ],
    [ "PrintData", "class_p_o_s_link_admin_1_1_device_1_1_printer_request.html#ac84a3edf8f4c022c12a753ab525954e8", null ]
];