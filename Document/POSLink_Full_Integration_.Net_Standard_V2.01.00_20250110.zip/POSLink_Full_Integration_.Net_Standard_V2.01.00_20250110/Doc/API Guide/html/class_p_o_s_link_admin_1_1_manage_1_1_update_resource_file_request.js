var class_p_o_s_link_admin_1_1_manage_1_1_update_resource_file_request =
[
    [ "FileType", "class_p_o_s_link_admin_1_1_manage_1_1_update_resource_file_request.html#a5fcf354fc7d61d655a07cd64e9765a84", null ],
    [ "FileUrl", "class_p_o_s_link_admin_1_1_manage_1_1_update_resource_file_request.html#aa128eff45f7300a82452362eb0f322c2", null ],
    [ "TargetDevice", "class_p_o_s_link_admin_1_1_manage_1_1_update_resource_file_request.html#adf870297f054ce6ba0cc6cff510f9650", null ]
];