var class_p_o_s_link_admin_1_1_device_1_1_mifare_card_request =
[
    [ "BlockNumber", "class_p_o_s_link_admin_1_1_device_1_1_mifare_card_request.html#ab006c467d8493e9ff5700ee0cee51d1f", null ],
    [ "BlockValue", "class_p_o_s_link_admin_1_1_device_1_1_mifare_card_request.html#a371683e2643cffcda1562fac05e1651a", null ],
    [ "M1Command", "class_p_o_s_link_admin_1_1_device_1_1_mifare_card_request.html#a65a717c079351c4677df3527987f3970", null ],
    [ "Password", "class_p_o_s_link_admin_1_1_device_1_1_mifare_card_request.html#ac11e395bf072a0a237e87fc412b9c041", null ],
    [ "PasswordType", "class_p_o_s_link_admin_1_1_device_1_1_mifare_card_request.html#a09a8e0d5549ad5763550dfcc1cefc1f4", null ],
    [ "Timeout", "class_p_o_s_link_admin_1_1_device_1_1_mifare_card_request.html#ac495ecfcde53ebecbbfd66fa9de340ad", null ],
    [ "UpdateBlockNumber", "class_p_o_s_link_admin_1_1_device_1_1_mifare_card_request.html#aa844a919ffe3f697a1c0c847f9a7d76b", null ]
];