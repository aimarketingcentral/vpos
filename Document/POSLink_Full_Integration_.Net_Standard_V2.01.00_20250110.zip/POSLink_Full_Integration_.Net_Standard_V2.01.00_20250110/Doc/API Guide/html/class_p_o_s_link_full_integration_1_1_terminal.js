var class_p_o_s_link_full_integration_1_1_terminal =
[
    [ "Cancel", "class_p_o_s_link_full_integration_1_1_terminal.html#a83a2eec8398b2aca86c550fca611cfc6", null ],
    [ "GetReportStatus", "class_p_o_s_link_full_integration_1_1_terminal.html#a600fb297f17cedbc5a6329a369a5d244", null ],
    [ "MultipleCommands", "class_p_o_s_link_full_integration_1_1_terminal.html#aae6f6879de4d5135e47fab21c48f5d2d", null ],
    [ "FullIntegration", "class_p_o_s_link_full_integration_1_1_terminal.html#a17b3476dc6524f19deb0b02931fe9f00", null ]
];