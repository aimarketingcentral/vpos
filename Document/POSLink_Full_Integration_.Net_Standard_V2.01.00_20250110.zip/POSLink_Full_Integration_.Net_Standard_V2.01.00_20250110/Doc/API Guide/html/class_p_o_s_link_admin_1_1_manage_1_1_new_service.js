var class_p_o_s_link_admin_1_1_manage_1_1_new_service =
[
    [ "Title", "class_p_o_s_link_admin_1_1_manage_1_1_new_service.html#aefe27199f5cf6d5417e3d71c816366bc", null ],
    [ "Type", "class_p_o_s_link_admin_1_1_manage_1_1_new_service.html#a2ee6a57902bde5d78cce431b99754932", null ],
    [ "Url", "class_p_o_s_link_admin_1_1_manage_1_1_new_service.html#a9f262aad0ff7cba82b0bf35396dd5882", null ]
];