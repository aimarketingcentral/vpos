var class_p_o_s_link_admin_1_1_util_1_1_offline_information_request =
[
    [ "DurationOfflineInDays", "class_p_o_s_link_admin_1_1_util_1_1_offline_information_request.html#abf3689480df4a2393e81d958d585f1ec", null ],
    [ "EndOfflineDateTime", "class_p_o_s_link_admin_1_1_util_1_1_offline_information_request.html#a59eba771435b1f06270224e132486299", null ],
    [ "StartOfflineDateTime", "class_p_o_s_link_admin_1_1_util_1_1_offline_information_request.html#ad66bfe70063b0843907a5f1fd8864dfd", null ]
];