var class_p_o_s_link_admin_1_1_manage_1_1_set_variable_request =
[
    [ "EdcType", "class_p_o_s_link_admin_1_1_manage_1_1_set_variable_request.html#a83e0f4a384294b70b14d66f05ad596bf", null ],
    [ "MultiMerchant", "class_p_o_s_link_admin_1_1_manage_1_1_set_variable_request.html#a1297055804efc4f0385e70ef5360adbe", null ],
    [ "VariableName1", "class_p_o_s_link_admin_1_1_manage_1_1_set_variable_request.html#a42df89c6ca5a6b6cfcd93439549363f4", null ],
    [ "VariableName2", "class_p_o_s_link_admin_1_1_manage_1_1_set_variable_request.html#a4a96066ec2e034bdac2e3b0df1097d45", null ],
    [ "VariableName3", "class_p_o_s_link_admin_1_1_manage_1_1_set_variable_request.html#a6e66415de2181c9a9921c342d606a055", null ],
    [ "VariableName4", "class_p_o_s_link_admin_1_1_manage_1_1_set_variable_request.html#a8188ba3f544bd7f3986af70e7ab2d99e", null ],
    [ "VariableName5", "class_p_o_s_link_admin_1_1_manage_1_1_set_variable_request.html#a8f67d5e0f9957cb671e697b4bbaa5746", null ],
    [ "VariableValue1", "class_p_o_s_link_admin_1_1_manage_1_1_set_variable_request.html#a0d62d2f0be79fb88dd9023adc287c96b", null ],
    [ "VariableValue2", "class_p_o_s_link_admin_1_1_manage_1_1_set_variable_request.html#a3df44b6af693c229301f1752a6c73fa8", null ],
    [ "VariableValue3", "class_p_o_s_link_admin_1_1_manage_1_1_set_variable_request.html#ae5a6bd782fab2fbb44ec961c5df6880b", null ],
    [ "VariableValue4", "class_p_o_s_link_admin_1_1_manage_1_1_set_variable_request.html#ab7ff79643f8ab3c91cab0fb73914e451", null ],
    [ "VariableValue5", "class_p_o_s_link_admin_1_1_manage_1_1_set_variable_request.html#a8872f57d53ea3be701af0b488043904a", null ]
];