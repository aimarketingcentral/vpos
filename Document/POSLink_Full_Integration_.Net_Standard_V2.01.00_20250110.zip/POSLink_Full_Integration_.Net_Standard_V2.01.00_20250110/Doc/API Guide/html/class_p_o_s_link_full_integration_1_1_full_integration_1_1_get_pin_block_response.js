var class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_response =
[
    [ "Ksn", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_response.html#aea6063236dc03ae5a780b9c494f7f093", null ],
    [ "PinBlock", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_response.html#a01d714f24ac0414f2c9f7ea6c9857b8b", null ],
    [ "PinpadType", "class_p_o_s_link_full_integration_1_1_full_integration_1_1_get_pin_block_response.html#af47abef35bbf0abe78ac929f31f88732", null ]
];