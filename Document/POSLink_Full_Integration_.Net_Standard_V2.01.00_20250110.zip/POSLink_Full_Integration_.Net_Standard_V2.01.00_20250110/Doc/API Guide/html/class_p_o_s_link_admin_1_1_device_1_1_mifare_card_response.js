var class_p_o_s_link_admin_1_1_device_1_1_mifare_card_response =
[
    [ "BlockValue", "class_p_o_s_link_admin_1_1_device_1_1_mifare_card_response.html#acb6dd3dcd756284c093b03f173084bf9", null ]
];