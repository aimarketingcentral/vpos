var class_p_o_s_link_admin_1_1_execution_result =
[
    [ "Code", "class_p_o_s_link_admin_1_1_execution_result.html#a850dfeb5162e8d28a6b1ed73841b5853", [
      [ "UnknownError", "class_p_o_s_link_admin_1_1_execution_result.html#a850dfeb5162e8d28a6b1ed73841b5853abfaef30f1c8011c5cefa38ae470fb7aa", null ],
      [ "Ok", "class_p_o_s_link_admin_1_1_execution_result.html#a850dfeb5162e8d28a6b1ed73841b5853aa60852f204ed8028c1c58808b746d115", null ],
      [ "RecvAckTimeout", "class_p_o_s_link_admin_1_1_execution_result.html#a850dfeb5162e8d28a6b1ed73841b5853a64f7b187d9f00a8d1afe07bdebf24a48", null ],
      [ "RecvDataTimeout", "class_p_o_s_link_admin_1_1_execution_result.html#a850dfeb5162e8d28a6b1ed73841b5853a621a686db5bbc0c6f95f1aba01374b0a", null ],
      [ "ConnectError", "class_p_o_s_link_admin_1_1_execution_result.html#a850dfeb5162e8d28a6b1ed73841b5853a3b26f2ffccae97443db33944eda7b269", null ],
      [ "SendDataError", "class_p_o_s_link_admin_1_1_execution_result.html#a850dfeb5162e8d28a6b1ed73841b5853ad1408f199a729af3889518489a7704e7", null ],
      [ "RecvAckError", "class_p_o_s_link_admin_1_1_execution_result.html#a850dfeb5162e8d28a6b1ed73841b5853ad64496cda1723a6e08bfe33b0b5f43b8", null ],
      [ "RecvDataError", "class_p_o_s_link_admin_1_1_execution_result.html#a850dfeb5162e8d28a6b1ed73841b5853abd7a50053743f744f680d35715940e75", null ],
      [ "ExceptionalHttpStatusCode", "class_p_o_s_link_admin_1_1_execution_result.html#a850dfeb5162e8d28a6b1ed73841b5853ab8981b5b1d677724e9c89045314f553c", null ],
      [ "LrcError", "class_p_o_s_link_admin_1_1_execution_result.html#a850dfeb5162e8d28a6b1ed73841b5853ab8ac96cd5233f4f13223a1d5b705b4a9", null ],
      [ "PackRequestError", "class_p_o_s_link_admin_1_1_execution_result.html#a850dfeb5162e8d28a6b1ed73841b5853aec3fe7ae3177238b40fcaf7dd8f6a74d", null ],
      [ "RequestDataIsNull", "class_p_o_s_link_admin_1_1_execution_result.html#a850dfeb5162e8d28a6b1ed73841b5853a493c5e9b1efdb6a263957e4376249cf0", null ]
    ] ],
    [ "ExecutionResult", "class_p_o_s_link_admin_1_1_execution_result.html#ab92214b60c6ad3a6d2a0bb5ea956c526", null ],
    [ "GetErrorCode", "class_p_o_s_link_admin_1_1_execution_result.html#a6ade9bfc13763e85baa3850409bb7d06", null ],
    [ "SetErrorCode", "class_p_o_s_link_admin_1_1_execution_result.html#a4a5cddce5ea7cdc084dc28574db41acc", null ]
];