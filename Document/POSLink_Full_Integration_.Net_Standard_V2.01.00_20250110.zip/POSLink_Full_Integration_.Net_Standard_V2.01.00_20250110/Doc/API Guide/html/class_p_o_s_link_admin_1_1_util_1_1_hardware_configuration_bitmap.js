var class_p_o_s_link_admin_1_1_util_1_1_hardware_configuration_bitmap =
[
    [ "CameraFront", "class_p_o_s_link_admin_1_1_util_1_1_hardware_configuration_bitmap.html#a5428abd7fd073c88749faa4bde400384", null ],
    [ "CameraRear", "class_p_o_s_link_admin_1_1_util_1_1_hardware_configuration_bitmap.html#a168e1e0abbdc187f41d6f2d2041fd521", null ],
    [ "EmvChip", "class_p_o_s_link_admin_1_1_util_1_1_hardware_configuration_bitmap.html#a96bc2a01bd3127f95e7b8634146c2822", null ],
    [ "EmvContactless", "class_p_o_s_link_admin_1_1_util_1_1_hardware_configuration_bitmap.html#a0e43ab117274253af44a0844dad22f07", null ],
    [ "LaserScanner", "class_p_o_s_link_admin_1_1_util_1_1_hardware_configuration_bitmap.html#ab0c85b25d59704e2d0861055bbcb36f5", null ],
    [ "Magstripe", "class_p_o_s_link_admin_1_1_util_1_1_hardware_configuration_bitmap.html#aa3cdf1270d88fc95d920c276e9b11fcc", null ],
    [ "Printer", "class_p_o_s_link_admin_1_1_util_1_1_hardware_configuration_bitmap.html#a851a80f67f4ea6c032b0e7431f26ef6f", null ],
    [ "Touchscreen", "class_p_o_s_link_admin_1_1_util_1_1_hardware_configuration_bitmap.html#a8a5e09cfbc9443f60ae667f152ec2ec2", null ]
];