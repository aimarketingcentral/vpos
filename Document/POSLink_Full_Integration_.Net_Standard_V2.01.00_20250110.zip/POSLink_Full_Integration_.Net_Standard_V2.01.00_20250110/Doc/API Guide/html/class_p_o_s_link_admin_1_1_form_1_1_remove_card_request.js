var class_p_o_s_link_admin_1_1_form_1_1_remove_card_request =
[
    [ "ContinuousScreen", "class_p_o_s_link_admin_1_1_form_1_1_remove_card_request.html#a66c2b50edd67cf81ab7101a07483b9c8", null ],
    [ "Icon", "class_p_o_s_link_admin_1_1_form_1_1_remove_card_request.html#a4140f9eed393989c9af3089a77461669", null ],
    [ "Message1", "class_p_o_s_link_admin_1_1_form_1_1_remove_card_request.html#a6abb83338b21fff2d4bac921af13d69f", null ],
    [ "Message2", "class_p_o_s_link_admin_1_1_form_1_1_remove_card_request.html#a6014de7f0ab05c6dee7556b77c145617", null ],
    [ "PinpadType", "class_p_o_s_link_admin_1_1_form_1_1_remove_card_request.html#ae47c2e3a6eb9bbb3098e0297c93b31ce", null ]
];