var class_p_o_s_link_admin_1_1_manage_1_1_delete_image_request =
[
    [ "ImageName", "class_p_o_s_link_admin_1_1_manage_1_1_delete_image_request.html#a3c66ffd876e7865d400383e9027b9ae6", null ]
];