var class_p_o_s_link2_1_1_manage_1_1_vas_set_merchant_parameters_rsp =
[
    [ "VasSetMerchantParametersRsp", "class_p_o_s_link2_1_1_manage_1_1_vas_set_merchant_parameters_rsp.html#a73bdd771a104253b2bf95dcc9efd681f", null ]
];