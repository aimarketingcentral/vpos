var class_p_o_s_link2_1_1_full_integration_1_1_set_emv_tlv_data_req =
[
    [ "SetEmvTlvDataReq", "class_p_o_s_link2_1_1_full_integration_1_1_set_emv_tlv_data_req.html#af2738065c7804c784e754995d23437e9", null ],
    [ "EmvTlvData", "class_p_o_s_link2_1_1_full_integration_1_1_set_emv_tlv_data_req.html#ae7a0d63163da2773becdcf0990a5668a", null ],
    [ "TlvType", "class_p_o_s_link2_1_1_full_integration_1_1_set_emv_tlv_data_req.html#a59866ebf66d4b42a8cc39476b6eb8a8a", null ]
];