var class_p_o_s_link2_1_1_manage_1_1_vas_set_merchant_parameters_req =
[
    [ "VasSetMerchantParametersReq", "class_p_o_s_link2_1_1_manage_1_1_vas_set_merchant_parameters_req.html#ab3b30f54e6c8e7761840d2921d8e2942", null ],
    [ "VasMode", "class_p_o_s_link2_1_1_manage_1_1_vas_set_merchant_parameters_req.html#a9846347efca96d491b1ad1a7b92f3e08", null ],
    [ "VasProgram", "class_p_o_s_link2_1_1_manage_1_1_vas_set_merchant_parameters_req.html#a97fe1321c4e9b7a24e1b167b790bcaf8", null ],
    [ "VasSpecificData", "class_p_o_s_link2_1_1_manage_1_1_vas_set_merchant_parameters_req.html#a089c4c4869461fec430e543903abe822", null ]
];