var class_p_o_s_link2_1_1_report_1_1_credit_totals =
[
    [ "AuthAmount", "class_p_o_s_link2_1_1_report_1_1_credit_totals.html#aec12694176126bf8a74f7365ab565e2a", null ],
    [ "AuthCount", "class_p_o_s_link2_1_1_report_1_1_credit_totals.html#a35eb68ee5ea509a7b329a9ba9a303d0d", null ],
    [ "ForcedAmount", "class_p_o_s_link2_1_1_report_1_1_credit_totals.html#a4fb1bf4e68efade232c289b7e1682964", null ],
    [ "ForcedCount", "class_p_o_s_link2_1_1_report_1_1_credit_totals.html#a671895489be092113077abf5c2b49ed2", null ],
    [ "PostauthAmount", "class_p_o_s_link2_1_1_report_1_1_credit_totals.html#a0c55023b9b6975efa2a53f017f47923c", null ],
    [ "PostauthCount", "class_p_o_s_link2_1_1_report_1_1_credit_totals.html#a2c5b377d73bfdc96742ed6879315a4df", null ],
    [ "ReturnAmount", "class_p_o_s_link2_1_1_report_1_1_credit_totals.html#a8f68b7f8fbb186081d229c7f4e653f40", null ],
    [ "ReturnCount", "class_p_o_s_link2_1_1_report_1_1_credit_totals.html#a324acf3e2e976a36dc9621af2e050d83", null ],
    [ "SaleAmount", "class_p_o_s_link2_1_1_report_1_1_credit_totals.html#a9cc050b7fbc01c9e9819e4e981196f9b", null ],
    [ "SaleCount", "class_p_o_s_link2_1_1_report_1_1_credit_totals.html#ae83d7082f87d0969fd11aa909f111e0d", null ]
];