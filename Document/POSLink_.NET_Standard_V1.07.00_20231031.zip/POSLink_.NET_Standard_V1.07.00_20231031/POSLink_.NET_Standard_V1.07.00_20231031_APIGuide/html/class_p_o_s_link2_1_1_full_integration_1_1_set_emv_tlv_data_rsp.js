var class_p_o_s_link2_1_1_full_integration_1_1_set_emv_tlv_data_rsp =
[
    [ "SetEmvTlvDataRsp", "class_p_o_s_link2_1_1_full_integration_1_1_set_emv_tlv_data_rsp.html#a58982c5b08de42041a2066203b056ade", null ],
    [ "TagList", "class_p_o_s_link2_1_1_full_integration_1_1_set_emv_tlv_data_rsp.html#a1e92c5eb965e2b2e62a029b2ac11e522", null ]
];