var class_p_o_s_link2_1_1_batch_1_1_force_batch_close_rsp =
[
    [ "ForceBatchCloseRsp", "class_p_o_s_link2_1_1_batch_1_1_force_batch_close_rsp.html#a96f7652988225455ba4b6e3d61623772", null ],
    [ "FailedCount", "class_p_o_s_link2_1_1_batch_1_1_force_batch_close_rsp.html#a4239651885f7b0f31ab1b3234a273930", null ],
    [ "FailedTransNO", "class_p_o_s_link2_1_1_batch_1_1_force_batch_close_rsp.html#a13de578bc1fbd58858055c388ed07266", null ],
    [ "HostInformation", "class_p_o_s_link2_1_1_batch_1_1_force_batch_close_rsp.html#a18a85446fd72467c3f2ce5124f91517d", null ],
    [ "LineNumber", "class_p_o_s_link2_1_1_batch_1_1_force_batch_close_rsp.html#a38a9e4b2c9b8b11dc266140a13cdaf2a", null ],
    [ "LinesMessage", "class_p_o_s_link2_1_1_batch_1_1_force_batch_close_rsp.html#ab29a4840205097b659e7ff20687664b5", null ],
    [ "Mid", "class_p_o_s_link2_1_1_batch_1_1_force_batch_close_rsp.html#a4cddab02c9d5cde8d1ad37beab636306", null ],
    [ "SafFailedCount", "class_p_o_s_link2_1_1_batch_1_1_force_batch_close_rsp.html#a6afcdac4dcc1452a24911e039bf5b903", null ],
    [ "SafFailedTotal", "class_p_o_s_link2_1_1_batch_1_1_force_batch_close_rsp.html#a28dc1c3d3747fb64a9b1e1948a988629", null ],
    [ "Tid", "class_p_o_s_link2_1_1_batch_1_1_force_batch_close_rsp.html#aad1d90829ff0893de6a885c4492ea1b9", null ],
    [ "TimeStamp", "class_p_o_s_link2_1_1_batch_1_1_force_batch_close_rsp.html#a2eec07da5954b7bcac709516b2c99e54", null ],
    [ "TorInformation", "class_p_o_s_link2_1_1_batch_1_1_force_batch_close_rsp.html#ad23426bf68925747367a8aa001edffa0", null ]
];