var class_p_o_s_link2_1_1_report_1_1_check_totals =
[
    [ "AdjustAmount", "class_p_o_s_link2_1_1_report_1_1_check_totals.html#a7ab1fc60bf7d2dedbd04a5ed76f48124", null ],
    [ "AdjustCount", "class_p_o_s_link2_1_1_report_1_1_check_totals.html#a57c43c7efe4bfa049fbf4046db6fda4e", null ],
    [ "SaleAmount", "class_p_o_s_link2_1_1_report_1_1_check_totals.html#ac80843bcd7e99c02569635bd4171e80b", null ],
    [ "SaleCount", "class_p_o_s_link2_1_1_report_1_1_check_totals.html#a7909794a1c6d9b8b69d004a3ca08f102", null ]
];