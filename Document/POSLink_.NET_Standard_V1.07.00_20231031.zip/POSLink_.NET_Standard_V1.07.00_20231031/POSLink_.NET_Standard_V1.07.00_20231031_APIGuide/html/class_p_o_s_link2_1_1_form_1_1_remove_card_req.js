var class_p_o_s_link2_1_1_form_1_1_remove_card_req =
[
    [ "RemoveCardReq", "class_p_o_s_link2_1_1_form_1_1_remove_card_req.html#a0c56dda339307dc7717586659234234b", null ],
    [ "ContinuousScreen", "class_p_o_s_link2_1_1_form_1_1_remove_card_req.html#a69d0ae539f3ac8aaa75f8589c56882a0", null ],
    [ "Message1", "class_p_o_s_link2_1_1_form_1_1_remove_card_req.html#aa09037593da55127d00b80e50465666e", null ],
    [ "Message2", "class_p_o_s_link2_1_1_form_1_1_remove_card_req.html#af19a4fc936f92133fea488c69a66c809", null ],
    [ "PinpadType", "class_p_o_s_link2_1_1_form_1_1_remove_card_req.html#a8a79356c524c47c0d39c7df5c1d0a4e5", null ]
];