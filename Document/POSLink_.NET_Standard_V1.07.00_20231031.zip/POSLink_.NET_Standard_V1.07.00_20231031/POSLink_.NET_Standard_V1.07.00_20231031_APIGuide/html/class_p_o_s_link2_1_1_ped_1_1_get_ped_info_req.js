var class_p_o_s_link2_1_1_ped_1_1_get_ped_info_req =
[
    [ "GetPedInfoReq", "class_p_o_s_link2_1_1_ped_1_1_get_ped_info_req.html#afd6961ae91fdfff67dc9e363093763ac", null ],
    [ "KeySlot", "class_p_o_s_link2_1_1_ped_1_1_get_ped_info_req.html#aad9c1cd1bc0f5086e773937cb54d3455", null ],
    [ "KeyType", "class_p_o_s_link2_1_1_ped_1_1_get_ped_info_req.html#a60a7322d3bc3272eaf636bbd858c10b9", null ]
];