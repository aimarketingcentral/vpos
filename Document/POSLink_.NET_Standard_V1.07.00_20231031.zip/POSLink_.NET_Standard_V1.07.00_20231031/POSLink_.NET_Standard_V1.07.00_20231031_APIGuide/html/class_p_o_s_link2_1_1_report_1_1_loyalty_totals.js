var class_p_o_s_link2_1_1_report_1_1_loyalty_totals =
[
    [ "ActivateAmount", "class_p_o_s_link2_1_1_report_1_1_loyalty_totals.html#aa1d769f883a84800fc7a7e6ecd36a501", null ],
    [ "ActivateCount", "class_p_o_s_link2_1_1_report_1_1_loyalty_totals.html#a528891e7e4f4d7b292592292e0f6b845", null ],
    [ "AddAmount", "class_p_o_s_link2_1_1_report_1_1_loyalty_totals.html#a69276f2f9a9b105590f0dc8c713a9a14", null ],
    [ "AddCount", "class_p_o_s_link2_1_1_report_1_1_loyalty_totals.html#a6262f6e3e1f23fd365779b68a0d510bb", null ],
    [ "DeactivateAmount", "class_p_o_s_link2_1_1_report_1_1_loyalty_totals.html#abc0bacf9ef7e510bc774c7a516c58519", null ],
    [ "DeactivateCount", "class_p_o_s_link2_1_1_report_1_1_loyalty_totals.html#a448bf092b9339fa685a898ce6c8c26ae", null ],
    [ "ForcedAmount", "class_p_o_s_link2_1_1_report_1_1_loyalty_totals.html#a3b08a50ca6377c3d94b2b010768e695c", null ],
    [ "ForcedCount", "class_p_o_s_link2_1_1_report_1_1_loyalty_totals.html#af290246b906c15d687bd2868cef89011", null ],
    [ "IssueAmount", "class_p_o_s_link2_1_1_report_1_1_loyalty_totals.html#a0cfc080d119681a151672e0b4dfccda3", null ],
    [ "IssueCount", "class_p_o_s_link2_1_1_report_1_1_loyalty_totals.html#ae17619742737e6df31d10d36f32d569e", null ],
    [ "RedeemAmount", "class_p_o_s_link2_1_1_report_1_1_loyalty_totals.html#aed42517f2f8243db65ac80835a66ec0b", null ],
    [ "RedeemCount", "class_p_o_s_link2_1_1_report_1_1_loyalty_totals.html#ac5bd36a15d550c68ea4ac9ae58f71152", null ],
    [ "ReturnAmount", "class_p_o_s_link2_1_1_report_1_1_loyalty_totals.html#a9d28f219e06660a3a99f1ddcbdd124b4", null ],
    [ "ReturnCount", "class_p_o_s_link2_1_1_report_1_1_loyalty_totals.html#a9b31fd97ccfccde2cdd22a9900b03248", null ]
];