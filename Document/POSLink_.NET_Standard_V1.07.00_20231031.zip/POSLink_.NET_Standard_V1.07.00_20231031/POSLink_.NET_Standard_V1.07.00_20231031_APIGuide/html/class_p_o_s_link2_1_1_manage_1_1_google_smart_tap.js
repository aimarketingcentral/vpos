var class_p_o_s_link2_1_1_manage_1_1_google_smart_tap =
[
    [ "GoogleSmartTap", "class_p_o_s_link2_1_1_manage_1_1_google_smart_tap.html#a7762c678916f7f46f2dd2f55f8146ea5", null ],
    [ "CollectId", "class_p_o_s_link2_1_1_manage_1_1_google_smart_tap.html#a428961afa9b0ed3323c32e875544d722", null ],
    [ "EndTap", "class_p_o_s_link2_1_1_manage_1_1_google_smart_tap.html#a4790b8b472cc07068f0cce26ca92e2fc", null ],
    [ "GoogleSmartTapCap", "class_p_o_s_link2_1_1_manage_1_1_google_smart_tap.html#a5e6f0fd635cbfba7e832456694057b1f", null ],
    [ "MerchantCategory", "class_p_o_s_link2_1_1_manage_1_1_google_smart_tap.html#aa18e640d2fda46ae8104600e8d17b896", null ],
    [ "MerchantName", "class_p_o_s_link2_1_1_manage_1_1_google_smart_tap.html#aa6350a35bdf269861f1919e3547784f1", null ],
    [ "OseToPpse", "class_p_o_s_link2_1_1_manage_1_1_google_smart_tap.html#a036b1b9370fb96f8ea584992cfc12367", null ],
    [ "Security", "class_p_o_s_link2_1_1_manage_1_1_google_smart_tap.html#aba9dff3b8ccf03c016c6255ee09e7865", null ],
    [ "ServiceType", "class_p_o_s_link2_1_1_manage_1_1_google_smart_tap.html#a742587fa873a647c1f13e16366c1a579", null ],
    [ "StoreLocalId", "class_p_o_s_link2_1_1_manage_1_1_google_smart_tap.html#a94202e81fb6b53e85be37719746b673e", null ],
    [ "TerminalId", "class_p_o_s_link2_1_1_manage_1_1_google_smart_tap.html#a4f20279d198ddc0c79c1302e3ed2b67f", null ]
];