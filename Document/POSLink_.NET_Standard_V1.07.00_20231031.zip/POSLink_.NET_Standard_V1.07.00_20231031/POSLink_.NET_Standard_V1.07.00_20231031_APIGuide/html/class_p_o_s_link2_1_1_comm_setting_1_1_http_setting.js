var class_p_o_s_link2_1_1_comm_setting_1_1_http_setting =
[
    [ "HttpSetting", "class_p_o_s_link2_1_1_comm_setting_1_1_http_setting.html#ad213bbc85fb6b845e136dc2ae8f4496c", null ],
    [ "HttpSetting", "class_p_o_s_link2_1_1_comm_setting_1_1_http_setting.html#a2d0383971c62324419cba86789b3f189", null ],
    [ "Ip", "class_p_o_s_link2_1_1_comm_setting_1_1_http_setting.html#a00e3c2296862e9da02a40e21da3488e7", null ],
    [ "Port", "class_p_o_s_link2_1_1_comm_setting_1_1_http_setting.html#acf8c24599562be4499ace5894160b7cd", null ],
    [ "Timeout", "class_p_o_s_link2_1_1_comm_setting_1_1_http_setting.html#ae6c28d3958cb1404f7fec561c4a0364b", null ]
];