var class_p_o_s_link2_1_1_comm_setting_1_1_customer_comm_setting =
[
    [ "Close", "class_p_o_s_link2_1_1_comm_setting_1_1_customer_comm_setting.html#a8fa25225eff74cc8614b2e2ef59c7e6a", null ],
    [ "IsSameCommunication", "class_p_o_s_link2_1_1_comm_setting_1_1_customer_comm_setting.html#a9b7ce8b479634812c8864918992a5df4", null ],
    [ "Open", "class_p_o_s_link2_1_1_comm_setting_1_1_customer_comm_setting.html#aaacfa94ac5c34b850f0f5755a074a63c", null ],
    [ "Read", "class_p_o_s_link2_1_1_comm_setting_1_1_customer_comm_setting.html#a8f72e4175fa99c3d26363193f597f65a", null ],
    [ "Write", "class_p_o_s_link2_1_1_comm_setting_1_1_customer_comm_setting.html#a12d027672e73b27e07f6d30d2d16dff7", null ],
    [ "Timeout", "class_p_o_s_link2_1_1_comm_setting_1_1_customer_comm_setting.html#a85f8378464e19270a3a709cadbca0be8", null ]
];