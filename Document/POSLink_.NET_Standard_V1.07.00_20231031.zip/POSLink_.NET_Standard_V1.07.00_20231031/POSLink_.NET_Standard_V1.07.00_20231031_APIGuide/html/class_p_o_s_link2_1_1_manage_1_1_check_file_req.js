var class_p_o_s_link2_1_1_manage_1_1_check_file_req =
[
    [ "CheckFileReq", "class_p_o_s_link2_1_1_manage_1_1_check_file_req.html#a4f17315ccfb6539cb1644800955cb838", null ],
    [ "FileName", "class_p_o_s_link2_1_1_manage_1_1_check_file_req.html#ae67baef97afac6e05fb5d55337669f58", null ]
];