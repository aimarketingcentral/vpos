var class_p_o_s_link2_1_1_batch_1_1_batch_close_rsp =
[
    [ "BatchCloseRsp", "class_p_o_s_link2_1_1_batch_1_1_batch_close_rsp.html#a2800e8153d316969ca82817e11bef4b4", null ],
    [ "FailedCount", "class_p_o_s_link2_1_1_batch_1_1_batch_close_rsp.html#a4c024d60649ad0f342a593ff71bb3ba1", null ],
    [ "FailedTransNO", "class_p_o_s_link2_1_1_batch_1_1_batch_close_rsp.html#a95b453f36770f8f3ebf254318a62c455", null ],
    [ "HostInformation", "class_p_o_s_link2_1_1_batch_1_1_batch_close_rsp.html#af1b277643168dd8e0fd2406367d7d478", null ],
    [ "Mid", "class_p_o_s_link2_1_1_batch_1_1_batch_close_rsp.html#a829516453e9142e4fb47bcf9fbe45354", null ],
    [ "MultiMerchant", "class_p_o_s_link2_1_1_batch_1_1_batch_close_rsp.html#a72e0aeb2260fe7e75c31b8d5c12c9d6a", null ],
    [ "SafFailedCount", "class_p_o_s_link2_1_1_batch_1_1_batch_close_rsp.html#a4cb6dfb0409b48baf07538aa4d4c9a73", null ],
    [ "SafFailedTotal", "class_p_o_s_link2_1_1_batch_1_1_batch_close_rsp.html#aa326d4fc168c2a0136dcf2a8f0a27b55", null ],
    [ "Tid", "class_p_o_s_link2_1_1_batch_1_1_batch_close_rsp.html#a909626481ff9155f8ade801a465d7f9d", null ],
    [ "TimeStamp", "class_p_o_s_link2_1_1_batch_1_1_batch_close_rsp.html#a6b8517cdbeb202fca23bbdbfbe2e8fae", null ],
    [ "TorInformation", "class_p_o_s_link2_1_1_batch_1_1_batch_close_rsp.html#af9fe9e941da64cbc42ef6f316df423e5", null ],
    [ "TotalAmount", "class_p_o_s_link2_1_1_batch_1_1_batch_close_rsp.html#af1893f469f265b3b3f1b7779c63ce29c", null ],
    [ "TotalCount", "class_p_o_s_link2_1_1_batch_1_1_batch_close_rsp.html#adff209f678c24df63dfc750c1d17cd2f", null ]
];