var class_p_o_s_link2_1_1_batch_1_1_purge_batch_rsp =
[
    [ "PurgeBatchRsp", "class_p_o_s_link2_1_1_batch_1_1_purge_batch_rsp.html#a3a568398401a27c666b4412f9bc1e711", null ],
    [ "HostInformation", "class_p_o_s_link2_1_1_batch_1_1_purge_batch_rsp.html#ae41fea5527dfe2f6f74b23b43687a828", null ],
    [ "LineNumber", "class_p_o_s_link2_1_1_batch_1_1_purge_batch_rsp.html#a1a6472ec30a3381b56ae00b433e51c59", null ],
    [ "LinesMessage", "class_p_o_s_link2_1_1_batch_1_1_purge_batch_rsp.html#ab5e3eb9c1655fd7c5680642c4a2fa1b9", null ],
    [ "Mid", "class_p_o_s_link2_1_1_batch_1_1_purge_batch_rsp.html#a2eaff591ed6e55d3b3aefa511ee3dbc1", null ],
    [ "Tid", "class_p_o_s_link2_1_1_batch_1_1_purge_batch_rsp.html#a693ac1b62aaa5892827cd0438d75dd9d", null ],
    [ "TimeStamp", "class_p_o_s_link2_1_1_batch_1_1_purge_batch_rsp.html#a288ce9f05d9561bfdf8dac668b05e36d", null ],
    [ "TorInformation", "class_p_o_s_link2_1_1_batch_1_1_purge_batch_rsp.html#aefe926a7ed919444c62e1fe571bf4dad", null ]
];