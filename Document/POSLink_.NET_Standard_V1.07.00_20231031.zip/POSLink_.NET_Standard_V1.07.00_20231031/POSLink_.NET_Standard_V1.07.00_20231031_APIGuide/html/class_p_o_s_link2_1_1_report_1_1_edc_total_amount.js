var class_p_o_s_link2_1_1_report_1_1_edc_total_amount =
[
    [ "EdcTotalAmount", "class_p_o_s_link2_1_1_report_1_1_edc_total_amount.html#a50985649b5ac8ecc0eebfd993b1fb250", null ],
    [ "CashAmount", "class_p_o_s_link2_1_1_report_1_1_edc_total_amount.html#ad1f41279ec9427c7a0a52272a104c5cd", null ],
    [ "CheckAmount", "class_p_o_s_link2_1_1_report_1_1_edc_total_amount.html#a6e5ebb6fd1a83ba1750716f5235358f6", null ],
    [ "CreditAmount", "class_p_o_s_link2_1_1_report_1_1_edc_total_amount.html#a163dbedc036a3a717428d51ca907661f", null ],
    [ "DebitAmount", "class_p_o_s_link2_1_1_report_1_1_edc_total_amount.html#a6e3343a852af0fd16ac9862e9540356d", null ],
    [ "EbtAmount", "class_p_o_s_link2_1_1_report_1_1_edc_total_amount.html#a5fda0cff7dc27dde964a96c286909564", null ],
    [ "GfitAmount", "class_p_o_s_link2_1_1_report_1_1_edc_total_amount.html#a09f00d26a729872aa7fbab39fdb0ffc8", null ],
    [ "LoyaltyAmount", "class_p_o_s_link2_1_1_report_1_1_edc_total_amount.html#a025f92f1124dc60023a29d2d498477b9", null ]
];