var class_p_o_s_link2_1_1_batch_1_1_delete_transaction_rsp =
[
    [ "DeleteTransactionRsp", "class_p_o_s_link2_1_1_batch_1_1_delete_transaction_rsp.html#a199da8bc4dd2d13518b487b31226a96a", null ],
    [ "TorInformation", "class_p_o_s_link2_1_1_batch_1_1_delete_transaction_rsp.html#af4b4cbb991272227225f7f4110b7df05", null ]
];