var class_p_o_s_link2_1_1_p_o_s_link2 =
[
    [ "POSLink2", "class_p_o_s_link2_1_1_p_o_s_link2.html#aa6b1badab98296fb10aa6b5c411b7b77", null ],
    [ "GetLogSetting", "class_p_o_s_link2_1_1_p_o_s_link2.html#a9d3d0c7ae3fb5ec7a32d1806b724661c", null ],
    [ "GetPOSLink2", "class_p_o_s_link2_1_1_p_o_s_link2.html#a828c0061d3d9df507b6bdb2803810c74", null ],
    [ "GetTerminal", "class_p_o_s_link2_1_1_p_o_s_link2.html#ac476907fc0ee957eb1e3167cebe5f186", null ],
    [ "RemoveTerminal", "class_p_o_s_link2_1_1_p_o_s_link2.html#ae9c5e2c7e76093cf6f7229ffa3817e0e", null ],
    [ "SetLogSetting", "class_p_o_s_link2_1_1_p_o_s_link2.html#a83b835e40cd26d1ff08be35b2f7b5753", null ]
];