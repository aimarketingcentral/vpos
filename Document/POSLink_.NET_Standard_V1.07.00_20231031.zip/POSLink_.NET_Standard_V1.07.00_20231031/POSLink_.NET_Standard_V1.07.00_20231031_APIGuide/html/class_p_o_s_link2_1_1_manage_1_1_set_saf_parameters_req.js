var class_p_o_s_link2_1_1_manage_1_1_set_saf_parameters_req =
[
    [ "SetSafParametersReq", "class_p_o_s_link2_1_1_manage_1_1_set_saf_parameters_req.html#a0d15d24979e5479c16a1de80138dedd5", null ],
    [ "AutoUploadIntervalTime", "class_p_o_s_link2_1_1_manage_1_1_set_saf_parameters_req.html#a5c42382f031c9086fa39eac11e1c3c25", null ],
    [ "CeilingAmountPerCardType", "class_p_o_s_link2_1_1_manage_1_1_set_saf_parameters_req.html#af0896bfa8b8a968464c5960df28d3e2d", null ],
    [ "DeleteSAFConfirmation", "class_p_o_s_link2_1_1_manage_1_1_set_saf_parameters_req.html#a87149e5926fb88ec0d735be3f8dcce75", null ],
    [ "DurationInDays", "class_p_o_s_link2_1_1_manage_1_1_set_saf_parameters_req.html#a88b792e84055064b532d5da0fb3e04fb", null ],
    [ "EndDateTime", "class_p_o_s_link2_1_1_manage_1_1_set_saf_parameters_req.html#a0476a40237bc6be782aa48225addefe6", null ],
    [ "HaloPerCardType", "class_p_o_s_link2_1_1_manage_1_1_set_saf_parameters_req.html#a882cc6b38f661ced94b7f40e40394ffe", null ],
    [ "MaxNumber", "class_p_o_s_link2_1_1_manage_1_1_set_saf_parameters_req.html#a9a7bfdfaf8574d7750218717b711953b", null ],
    [ "SafMode", "class_p_o_s_link2_1_1_manage_1_1_set_saf_parameters_req.html#ad12487b863db198bb05df82fcc27d303", null ],
    [ "StartDateTime", "class_p_o_s_link2_1_1_manage_1_1_set_saf_parameters_req.html#a2cb86f15a020ff90dbbd6fe8c53a35f9", null ],
    [ "TotalCeilingAmount", "class_p_o_s_link2_1_1_manage_1_1_set_saf_parameters_req.html#a533cd89fac573db992c6aa6f2b59e3dd", null ],
    [ "UploadMode", "class_p_o_s_link2_1_1_manage_1_1_set_saf_parameters_req.html#a8089b0f9f5a44a3a5df457a490f8915e", null ]
];