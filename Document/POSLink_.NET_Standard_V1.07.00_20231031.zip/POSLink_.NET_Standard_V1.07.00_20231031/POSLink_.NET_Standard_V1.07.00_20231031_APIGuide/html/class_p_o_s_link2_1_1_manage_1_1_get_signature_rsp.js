var class_p_o_s_link2_1_1_manage_1_1_get_signature_rsp =
[
    [ "GetSignatureRsp", "class_p_o_s_link2_1_1_manage_1_1_get_signature_rsp.html#acfa3285139e1b3535e4ce281956b14ba", null ],
    [ "SignatureData", "class_p_o_s_link2_1_1_manage_1_1_get_signature_rsp.html#aa7d99422b6a0fbd96fc0b867ff51c207", null ]
];