var class_p_o_s_link2_1_1_form_1_1_show_message_center_req =
[
    [ "ShowMessageCenterReq", "class_p_o_s_link2_1_1_form_1_1_show_message_center_req.html#aca10e36246574f6639b75edb163ac43e", null ],
    [ "IconName", "class_p_o_s_link2_1_1_form_1_1_show_message_center_req.html#ac5fe44bf4d049e8bf91c1f76bf40a9b5", null ],
    [ "Message1", "class_p_o_s_link2_1_1_form_1_1_show_message_center_req.html#a207a40d8d9e4e70726637959943d0d15", null ],
    [ "Message2", "class_p_o_s_link2_1_1_form_1_1_show_message_center_req.html#ac647e651cace33daa0ef5309ea26f3e0", null ],
    [ "PinpadType", "class_p_o_s_link2_1_1_form_1_1_show_message_center_req.html#ad37d5eccdac75e73b0bb46baee554b1d", null ],
    [ "Timeout", "class_p_o_s_link2_1_1_form_1_1_show_message_center_req.html#ae418734a56868f5ac76bcaf5a815c17e", null ],
    [ "Title", "class_p_o_s_link2_1_1_form_1_1_show_message_center_req.html#a68c9b1096058d6fcf9513bdef729c377", null ]
];