var class_p_o_s_link2_1_1_report_1_1_saf_summary_report_req =
[
    [ "SafSummaryReportReq", "class_p_o_s_link2_1_1_report_1_1_saf_summary_report_req.html#ada044fa5ca842ddf356f8e927e8a0713", null ],
    [ "SafIndicator", "class_p_o_s_link2_1_1_report_1_1_saf_summary_report_req.html#a7602a436c262a07996c6ab5f30991e33", null ]
];