var class_p_o_s_link2_1_1_manage_1_1_get_saf_parameters_rsp =
[
    [ "GetSafParametersRsp", "class_p_o_s_link2_1_1_manage_1_1_get_saf_parameters_rsp.html#a72b65ba53a7db033342ea974aa910bf0", null ],
    [ "AutoUploadIntervalTime", "class_p_o_s_link2_1_1_manage_1_1_get_saf_parameters_rsp.html#a0937e8255e5f58e5006a5a0c20e7505f", null ],
    [ "CeilingAmountPerCardType", "class_p_o_s_link2_1_1_manage_1_1_get_saf_parameters_rsp.html#a797b919351fde4438e3618e0143ccb5e", null ],
    [ "DeleteSAFConfirmation", "class_p_o_s_link2_1_1_manage_1_1_get_saf_parameters_rsp.html#a1a47641adee510051fd4f34e6290a580", null ],
    [ "DurationInDays", "class_p_o_s_link2_1_1_manage_1_1_get_saf_parameters_rsp.html#ac279a82649c4a2e769f3262c344aef45", null ],
    [ "EndDateTime", "class_p_o_s_link2_1_1_manage_1_1_get_saf_parameters_rsp.html#aadfe50594f93516e8af0b1ea0da6c605", null ],
    [ "HaloPerCardType", "class_p_o_s_link2_1_1_manage_1_1_get_saf_parameters_rsp.html#a128d4157486e4bc3240a7b0a49836ecb", null ],
    [ "MaxNumber", "class_p_o_s_link2_1_1_manage_1_1_get_saf_parameters_rsp.html#a9988d8a12cb4cfcb055e763362e898a3", null ],
    [ "SafMode", "class_p_o_s_link2_1_1_manage_1_1_get_saf_parameters_rsp.html#a166c3bc772237d33d03bdaff2597382f", null ],
    [ "StartDateTime", "class_p_o_s_link2_1_1_manage_1_1_get_saf_parameters_rsp.html#a6ac6bd6031abe1f7e5b4cf229fe07b70", null ],
    [ "TotalCeilingAmount", "class_p_o_s_link2_1_1_manage_1_1_get_saf_parameters_rsp.html#afd14726772cbc5d6524183fe0bb76795", null ],
    [ "UploadMode", "class_p_o_s_link2_1_1_manage_1_1_get_saf_parameters_rsp.html#acf616ddab1b9080b3ce022bb93c01645", null ]
];