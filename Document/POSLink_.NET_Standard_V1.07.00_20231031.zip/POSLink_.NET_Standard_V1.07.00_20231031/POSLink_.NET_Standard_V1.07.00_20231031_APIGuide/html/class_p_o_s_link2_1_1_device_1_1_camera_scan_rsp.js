var class_p_o_s_link2_1_1_device_1_1_camera_scan_rsp =
[
    [ "CameraScanRsp", "class_p_o_s_link2_1_1_device_1_1_camera_scan_rsp.html#a48b8ef863ac160550f92bbea01c21539", null ],
    [ "BarcodeData", "class_p_o_s_link2_1_1_device_1_1_camera_scan_rsp.html#a65a461d65adb5f4b4419c1c4522d0b3c", null ],
    [ "BarcodeType", "class_p_o_s_link2_1_1_device_1_1_camera_scan_rsp.html#ab3c291f9007a5d1f779ce1bff868cfed", null ]
];