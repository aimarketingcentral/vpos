var class_p_o_s_link2_1_1_batch_1_1_batch =
[
    [ "BatchClear", "class_p_o_s_link2_1_1_batch_1_1_batch.html#ada103e7b90db2c82e4543f30f7091b95", null ],
    [ "BatchClose", "class_p_o_s_link2_1_1_batch_1_1_batch.html#a5469641b7eebec06e0bbbf1941e2d4f8", null ],
    [ "DeleteSafFile", "class_p_o_s_link2_1_1_batch_1_1_batch.html#a1c09e20e14c53fd18be9017559c5b3e3", null ],
    [ "DeleteTransaction", "class_p_o_s_link2_1_1_batch_1_1_batch.html#a8efff54183b0b669251643a32e740428", null ],
    [ "ForceBatchClose", "class_p_o_s_link2_1_1_batch_1_1_batch.html#a20b1b888420bb6c33cd4a095b0ff8c49", null ],
    [ "PurgeBatch", "class_p_o_s_link2_1_1_batch_1_1_batch.html#ae0204174456893744d8db39ae79bcd93", null ],
    [ "SafUpload", "class_p_o_s_link2_1_1_batch_1_1_batch.html#a8cd64da25f659949bc5842bbc8b91211", null ]
];