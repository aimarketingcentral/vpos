var class_p_o_s_link2_1_1_comm_setting_1_1_tcp_setting =
[
    [ "TcpSetting", "class_p_o_s_link2_1_1_comm_setting_1_1_tcp_setting.html#abf1436cb3d43ce666385787c128512ff", null ],
    [ "TcpSetting", "class_p_o_s_link2_1_1_comm_setting_1_1_tcp_setting.html#a471edcc4608f889fb909a3248916747f", null ],
    [ "Ip", "class_p_o_s_link2_1_1_comm_setting_1_1_tcp_setting.html#a46d83d78ca16bf8e021c68d6b7433bf4", null ],
    [ "Port", "class_p_o_s_link2_1_1_comm_setting_1_1_tcp_setting.html#a9a921096570bcfe76e53a6c72f51f1ca", null ],
    [ "Timeout", "class_p_o_s_link2_1_1_comm_setting_1_1_tcp_setting.html#a414e0e089b08d52008aaeaa4a57422d9", null ]
];