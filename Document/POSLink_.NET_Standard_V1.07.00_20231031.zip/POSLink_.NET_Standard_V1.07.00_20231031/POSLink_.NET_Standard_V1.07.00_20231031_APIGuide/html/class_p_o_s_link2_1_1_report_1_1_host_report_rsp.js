var class_p_o_s_link2_1_1_report_1_1_host_report_rsp =
[
    [ "HostReportRsp", "class_p_o_s_link2_1_1_report_1_1_host_report_rsp.html#a04c1f3f61b66c6b6f5413e2f60bddaf3", null ],
    [ "LineNumber", "class_p_o_s_link2_1_1_report_1_1_host_report_rsp.html#ae0c4369ba956e5135d910b5113d0215d", null ],
    [ "LinesMessage", "class_p_o_s_link2_1_1_report_1_1_host_report_rsp.html#afec6e49a1b1f8b7c8de5f21267e22467", null ],
    [ "ReportType", "class_p_o_s_link2_1_1_report_1_1_host_report_rsp.html#a56f5563b81c05ebcbaf2d7632af6431e", null ],
    [ "TimeStamp", "class_p_o_s_link2_1_1_report_1_1_host_report_rsp.html#a365f2ffc9064da6d3ed391629bd15486", null ]
];