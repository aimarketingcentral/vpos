var class_p_o_s_link2_1_1_manage_1_1_init_rsp =
[
    [ "InitRsp", "class_p_o_s_link2_1_1_manage_1_1_init_rsp.html#a3d57915707dc20c1a5e9d0ca0d2371be", null ],
    [ "AppName", "class_p_o_s_link2_1_1_manage_1_1_init_rsp.html#a0156986c3727618d9afc34b24d6291cc", null ],
    [ "AppVersion", "class_p_o_s_link2_1_1_manage_1_1_init_rsp.html#a3ee11e8dcc9e9ea54a7271b4e2f847bf", null ],
    [ "CharsPerLine", "class_p_o_s_link2_1_1_manage_1_1_init_rsp.html#a4b76c76652c1c14c08e0ee9ddae7fc3a", null ],
    [ "DeviceInfo", "class_p_o_s_link2_1_1_manage_1_1_init_rsp.html#ad21652d812863b50883f431675831519", null ],
    [ "HardwareConfigurationBitmap", "class_p_o_s_link2_1_1_manage_1_1_init_rsp.html#aa2c6136ad6dfb9f109a9a0d6baeee163", null ],
    [ "LinesPerScreen", "class_p_o_s_link2_1_1_manage_1_1_init_rsp.html#aa2a3e264b0fd86a806b8fcab6090cd10", null ],
    [ "MacAddress", "class_p_o_s_link2_1_1_manage_1_1_init_rsp.html#a6ffefc320d03b04805f94a8d00030bb8", null ],
    [ "ModelName", "class_p_o_s_link2_1_1_manage_1_1_init_rsp.html#ae44c7f83d25f515ab9b6eef995e3d0c8", null ],
    [ "OsVersion", "class_p_o_s_link2_1_1_manage_1_1_init_rsp.html#a825dd13d52a2b09a03501c1d2ae381d5", null ],
    [ "Sn", "class_p_o_s_link2_1_1_manage_1_1_init_rsp.html#a46fab10396081031a1c85b097dfa9cc3", null ],
    [ "Touchscreen", "class_p_o_s_link2_1_1_manage_1_1_init_rsp.html#a735bbd79ffe8b62804ba909aa425090c", null ],
    [ "WifiMac", "class_p_o_s_link2_1_1_manage_1_1_init_rsp.html#a541cdb1c1d1d288f2352d9c5ea2f5489", null ]
];