var class_p_o_s_link2_1_1_form_1_1_show_dialog_req =
[
    [ "ShowDialogReq", "class_p_o_s_link2_1_1_form_1_1_show_dialog_req.html#a0a9e3d69b0307472eb6379341ac83d95", null ],
    [ "ButtonName1", "class_p_o_s_link2_1_1_form_1_1_show_dialog_req.html#a16b386ba3d556766ba2aceb7cfda1cb2", null ],
    [ "ButtonName2", "class_p_o_s_link2_1_1_form_1_1_show_dialog_req.html#a0c21c9b2635e9c8b06e102557c739fa8", null ],
    [ "ButtonName3", "class_p_o_s_link2_1_1_form_1_1_show_dialog_req.html#af78d593496d574ada073a2c4165d34a0", null ],
    [ "ButtonName4", "class_p_o_s_link2_1_1_form_1_1_show_dialog_req.html#a437233653e9dd693c49d8ade06e52459", null ],
    [ "ContinuousScreen", "class_p_o_s_link2_1_1_form_1_1_show_dialog_req.html#a69acd725b2831ff508890a78b2ff86ec", null ],
    [ "Timeout", "class_p_o_s_link2_1_1_form_1_1_show_dialog_req.html#a50591c10a2ac3bc6e7a3a1ed74a94b46", null ],
    [ "Title", "class_p_o_s_link2_1_1_form_1_1_show_dialog_req.html#a6fb379826627d5f015ba57a7aed0321c", null ]
];