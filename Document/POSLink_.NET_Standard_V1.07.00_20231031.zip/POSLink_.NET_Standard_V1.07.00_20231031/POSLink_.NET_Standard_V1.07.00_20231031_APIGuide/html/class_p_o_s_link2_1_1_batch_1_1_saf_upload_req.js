var class_p_o_s_link2_1_1_batch_1_1_saf_upload_req =
[
    [ "SafUploadReq", "class_p_o_s_link2_1_1_batch_1_1_saf_upload_req.html#a88811684e2c2ef1677f061c2a30f8c67", null ],
    [ "SafIndicator", "class_p_o_s_link2_1_1_batch_1_1_saf_upload_req.html#a8bcecd4ff888d3589c0207b9132337d3", null ]
];