var class_p_o_s_link2_1_1_full_integration_1_1_get_emv_tlv_data_rsp =
[
    [ "GetEmvTlvDataRsp", "class_p_o_s_link2_1_1_full_integration_1_1_get_emv_tlv_data_rsp.html#aa4d193e84617001775d798c5cfa2e030", null ],
    [ "EmvTlvData", "class_p_o_s_link2_1_1_full_integration_1_1_get_emv_tlv_data_rsp.html#a55e9f9cfcffddce2176ec0fecd877f2a", null ]
];