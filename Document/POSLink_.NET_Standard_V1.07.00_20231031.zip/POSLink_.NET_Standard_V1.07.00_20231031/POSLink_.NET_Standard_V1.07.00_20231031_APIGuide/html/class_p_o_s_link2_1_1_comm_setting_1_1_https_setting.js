var class_p_o_s_link2_1_1_comm_setting_1_1_https_setting =
[
    [ "HttpsSetting", "class_p_o_s_link2_1_1_comm_setting_1_1_https_setting.html#a521ac3b8144541cea641916423a1ffd1", null ],
    [ "HttpsSetting", "class_p_o_s_link2_1_1_comm_setting_1_1_https_setting.html#a6fdef128db05db7f1e5d52a74171e44b", null ],
    [ "Ip", "class_p_o_s_link2_1_1_comm_setting_1_1_https_setting.html#a75edcd21f276bdd9ce7fb4b22df79870", null ],
    [ "Port", "class_p_o_s_link2_1_1_comm_setting_1_1_https_setting.html#acd8fabfaa0b24d4fa00c2fb04341a7eb", null ],
    [ "Timeout", "class_p_o_s_link2_1_1_comm_setting_1_1_https_setting.html#a1b49d5d89cb8612d2d171dbd64a73e15", null ]
];