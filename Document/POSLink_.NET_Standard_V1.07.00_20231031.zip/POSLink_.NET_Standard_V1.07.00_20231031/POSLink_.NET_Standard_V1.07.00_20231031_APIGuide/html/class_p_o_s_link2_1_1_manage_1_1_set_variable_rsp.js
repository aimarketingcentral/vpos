var class_p_o_s_link2_1_1_manage_1_1_set_variable_rsp =
[
    [ "SetVariableRsp", "class_p_o_s_link2_1_1_manage_1_1_set_variable_rsp.html#a6381e608e88726e06040755870119ca4", null ],
    [ "MultiMerchant", "class_p_o_s_link2_1_1_manage_1_1_set_variable_rsp.html#a5ecaf35ef50da554a2c817e508181120", null ]
];