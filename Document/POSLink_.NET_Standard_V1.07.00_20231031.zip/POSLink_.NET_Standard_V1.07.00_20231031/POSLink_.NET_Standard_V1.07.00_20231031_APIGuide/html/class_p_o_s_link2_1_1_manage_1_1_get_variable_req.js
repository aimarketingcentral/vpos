var class_p_o_s_link2_1_1_manage_1_1_get_variable_req =
[
    [ "GetVariableReq", "class_p_o_s_link2_1_1_manage_1_1_get_variable_req.html#a87a2bfc31e17d6cb9776055b51e38638", null ],
    [ "EdcType", "class_p_o_s_link2_1_1_manage_1_1_get_variable_req.html#a248387af0dd99343b4b5ea1467d82582", null ],
    [ "MultiMerchant", "class_p_o_s_link2_1_1_manage_1_1_get_variable_req.html#af239808a39bd976bc92cbca1015412c2", null ],
    [ "VariableName1", "class_p_o_s_link2_1_1_manage_1_1_get_variable_req.html#a58f346f72937e76d6783ac6541791508", null ],
    [ "VariableName2", "class_p_o_s_link2_1_1_manage_1_1_get_variable_req.html#ad8dcc7a2d1beb67acb64f53780f9614e", null ],
    [ "VariableName3", "class_p_o_s_link2_1_1_manage_1_1_get_variable_req.html#a075fa15fc3091249162e222d74674d05", null ],
    [ "VariableName4", "class_p_o_s_link2_1_1_manage_1_1_get_variable_req.html#ad3aa39279f11a5b4cbd4b41218d62782", null ],
    [ "VariableName5", "class_p_o_s_link2_1_1_manage_1_1_get_variable_req.html#a875f2260f4bb2989821a7b4516ee0985", null ]
];