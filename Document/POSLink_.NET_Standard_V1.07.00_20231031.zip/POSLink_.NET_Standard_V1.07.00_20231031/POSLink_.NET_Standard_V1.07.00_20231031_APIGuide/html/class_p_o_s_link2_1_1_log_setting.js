var class_p_o_s_link2_1_1_log_setting =
[
    [ "LogLevel", "class_p_o_s_link2_1_1_log_setting.html#a3ac2ca0b96862f4fe3526c0f8a51f892", [
      [ "Error", "class_p_o_s_link2_1_1_log_setting.html#a3ac2ca0b96862f4fe3526c0f8a51f892a902b0d55fddef6f8d651fe1035b7d4bd", null ],
      [ "Debug", "class_p_o_s_link2_1_1_log_setting.html#a3ac2ca0b96862f4fe3526c0f8a51f892aa603905470e2a5b8c13e96b579ef0dba", null ]
    ] ],
    [ "LogSetting", "class_p_o_s_link2_1_1_log_setting.html#a688403b1dfd76408a213fb7b1d7c601e", null ],
    [ "Days", "class_p_o_s_link2_1_1_log_setting.html#a90a625e8651f029a1168efd57bb68e38", null ],
    [ "Enabled", "class_p_o_s_link2_1_1_log_setting.html#afe42ef1949c193f874cbad0376f30c1f", null ],
    [ "FileName", "class_p_o_s_link2_1_1_log_setting.html#af93a36bddf2448be6733f2c5b8cfb4d8", null ],
    [ "FilePath", "class_p_o_s_link2_1_1_log_setting.html#afcd87b428a26824d2cd06cba7521991e", null ],
    [ "Level", "class_p_o_s_link2_1_1_log_setting.html#aa5f8d64b6965505cc8ab7d596e1f6831", null ]
];