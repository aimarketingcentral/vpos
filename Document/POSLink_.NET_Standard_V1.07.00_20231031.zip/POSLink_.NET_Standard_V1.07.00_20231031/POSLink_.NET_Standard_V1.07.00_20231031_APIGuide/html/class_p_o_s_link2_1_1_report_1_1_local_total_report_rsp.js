var class_p_o_s_link2_1_1_report_1_1_local_total_report_rsp =
[
    [ "LocalTotalReportRsp", "class_p_o_s_link2_1_1_report_1_1_local_total_report_rsp.html#aafd05a5b4a33c4051b0588489d25ed82", null ],
    [ "EdcType", "class_p_o_s_link2_1_1_report_1_1_local_total_report_rsp.html#a5c85d187d1f18697b95e1df0bf45e654", null ],
    [ "Totals", "class_p_o_s_link2_1_1_report_1_1_local_total_report_rsp.html#aca9f20ebc0015ac274c09b94c7fc0f7f", null ]
];