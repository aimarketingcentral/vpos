var class_p_o_s_link2_1_1_manage_1_1_set_variable_req =
[
    [ "SetVariableReq", "class_p_o_s_link2_1_1_manage_1_1_set_variable_req.html#ab2cd83c11f95ae26e0b3bb366a7d4cf6", null ],
    [ "EdcType", "class_p_o_s_link2_1_1_manage_1_1_set_variable_req.html#a792c1c46a2b7688764f637cb7293da23", null ],
    [ "MultiMerchant", "class_p_o_s_link2_1_1_manage_1_1_set_variable_req.html#a76e089c9f80a5d56991201e96d004936", null ],
    [ "VariableName1", "class_p_o_s_link2_1_1_manage_1_1_set_variable_req.html#a8e79f96d4da8b8ef4f9cbd8321b76aea", null ],
    [ "VariableName2", "class_p_o_s_link2_1_1_manage_1_1_set_variable_req.html#a45da232ecf1943b05f11927d4b54286b", null ],
    [ "VariableName3", "class_p_o_s_link2_1_1_manage_1_1_set_variable_req.html#aa253f958d8244c1527fb323de529f464", null ],
    [ "VariableName4", "class_p_o_s_link2_1_1_manage_1_1_set_variable_req.html#a609f7d62b548a8cd492f88b3916e0770", null ],
    [ "VariableName5", "class_p_o_s_link2_1_1_manage_1_1_set_variable_req.html#ab39afd05dacbbacac7b1e8a51d1f573c", null ],
    [ "VariableValue1", "class_p_o_s_link2_1_1_manage_1_1_set_variable_req.html#ac83fd49862042e618849c566d1dfa2d6", null ],
    [ "VariableValue2", "class_p_o_s_link2_1_1_manage_1_1_set_variable_req.html#a8f8a960282ed7a86667a42dfdb92b903", null ],
    [ "VariableValue3", "class_p_o_s_link2_1_1_manage_1_1_set_variable_req.html#a3caee237cdf4111482ebf952d682a486", null ],
    [ "VariableValue4", "class_p_o_s_link2_1_1_manage_1_1_set_variable_req.html#a0016ad05ee79979dad8e12448d044fbb", null ],
    [ "VariableValue5", "class_p_o_s_link2_1_1_manage_1_1_set_variable_req.html#a8b913bf8284c78c2f9c8935d9f50f479", null ]
];