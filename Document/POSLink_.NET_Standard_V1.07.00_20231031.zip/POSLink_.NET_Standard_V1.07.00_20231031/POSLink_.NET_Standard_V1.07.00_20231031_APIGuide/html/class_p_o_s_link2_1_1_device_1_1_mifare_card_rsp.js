var class_p_o_s_link2_1_1_device_1_1_mifare_card_rsp =
[
    [ "MifareCardRsp", "class_p_o_s_link2_1_1_device_1_1_mifare_card_rsp.html#a21eb2b5bda78da779d24e3fd99297190", null ],
    [ "BlockValue", "class_p_o_s_link2_1_1_device_1_1_mifare_card_rsp.html#a8b5261ad140238a5c1b419aa5bcec5e3", null ]
];