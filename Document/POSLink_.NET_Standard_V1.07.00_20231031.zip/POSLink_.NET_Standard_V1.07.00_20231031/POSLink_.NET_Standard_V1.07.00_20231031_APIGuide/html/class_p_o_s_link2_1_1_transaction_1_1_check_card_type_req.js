var class_p_o_s_link2_1_1_transaction_1_1_check_card_type_req =
[
    [ "CheckCardTypeReq", "class_p_o_s_link2_1_1_transaction_1_1_check_card_type_req.html#a46f793a29d5517cbb3d48e0a33b4680c", null ],
    [ "AmountInformation", "class_p_o_s_link2_1_1_transaction_1_1_check_card_type_req.html#a24f6b924e1836f00088dbaeecd4475c3", null ],
    [ "Original", "class_p_o_s_link2_1_1_transaction_1_1_check_card_type_req.html#af031e009aa4b1ad4e2edd1d290232b83", null ],
    [ "TraceInformation", "class_p_o_s_link2_1_1_transaction_1_1_check_card_type_req.html#a5ea982ae54722da2dee7e9dad9c9ed7a", null ],
    [ "TransactionType", "class_p_o_s_link2_1_1_transaction_1_1_check_card_type_req.html#a61caeeb05f87c410194df8fa3b155f44", null ]
];