var class_p_o_s_link2_1_1_manage_1_1_delete_image_req =
[
    [ "DeleteImageReq", "class_p_o_s_link2_1_1_manage_1_1_delete_image_req.html#a03e6eb6a0766ced8c1df0f978585b0ca", null ],
    [ "ImageName", "class_p_o_s_link2_1_1_manage_1_1_delete_image_req.html#a94f23902808eb791e0722d1ab6b87075", null ]
];