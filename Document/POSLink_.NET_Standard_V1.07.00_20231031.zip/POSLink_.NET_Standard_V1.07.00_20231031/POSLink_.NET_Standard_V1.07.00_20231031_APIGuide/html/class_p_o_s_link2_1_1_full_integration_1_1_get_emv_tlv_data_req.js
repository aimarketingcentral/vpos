var class_p_o_s_link2_1_1_full_integration_1_1_get_emv_tlv_data_req =
[
    [ "GetEmvTlvDataReq", "class_p_o_s_link2_1_1_full_integration_1_1_get_emv_tlv_data_req.html#a5105fef4bcb8e26ba06fab2beedeaea4", null ],
    [ "TagList", "class_p_o_s_link2_1_1_full_integration_1_1_get_emv_tlv_data_req.html#a189564a4c88fa4a69f056e83b8031c83", null ],
    [ "TlvType", "class_p_o_s_link2_1_1_full_integration_1_1_get_emv_tlv_data_req.html#a04b9d8e639a0b00d49d0927b04f6343a", null ]
];