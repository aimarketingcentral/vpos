var class_p_o_s_link2_1_1_device_1_1_mifare_card =
[
    [ "Operate", "class_p_o_s_link2_1_1_device_1_1_mifare_card.html#aa51c436dca9c17fa85cee14003a90d6f", null ]
];