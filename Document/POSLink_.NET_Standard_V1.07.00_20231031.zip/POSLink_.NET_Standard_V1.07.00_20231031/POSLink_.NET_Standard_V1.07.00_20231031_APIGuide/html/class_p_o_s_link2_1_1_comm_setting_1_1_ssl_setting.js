var class_p_o_s_link2_1_1_comm_setting_1_1_ssl_setting =
[
    [ "SslSetting", "class_p_o_s_link2_1_1_comm_setting_1_1_ssl_setting.html#a1a8d4bb8e61a6d79e5f91fcded8ed6b1", null ],
    [ "SslSetting", "class_p_o_s_link2_1_1_comm_setting_1_1_ssl_setting.html#a61e583d893e867dfeeaf38d2a5ef22d4", null ],
    [ "Ip", "class_p_o_s_link2_1_1_comm_setting_1_1_ssl_setting.html#a787eacb247cd149cfcdad7c8ddbf7cc7", null ],
    [ "Port", "class_p_o_s_link2_1_1_comm_setting_1_1_ssl_setting.html#a7cc4b58c526882d7f2e08175ed691e55", null ],
    [ "Timeout", "class_p_o_s_link2_1_1_comm_setting_1_1_ssl_setting.html#a5c2f696b02365fa0f1a577d5000647a0", null ]
];