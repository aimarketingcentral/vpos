var class_p_o_s_link2_1_1_device_1_1_mifare_card_req =
[
    [ "MifareCardReq", "class_p_o_s_link2_1_1_device_1_1_mifare_card_req.html#a63fc02b65bb6929fd6fbe82a3fdcdbd6", null ],
    [ "BlockNo", "class_p_o_s_link2_1_1_device_1_1_mifare_card_req.html#a522c85c1027bd7098872bfd7a239e5cb", null ],
    [ "BlockValue", "class_p_o_s_link2_1_1_device_1_1_mifare_card_req.html#a42406d27c6bd3341a122b8880f603174", null ],
    [ "M1Command", "class_p_o_s_link2_1_1_device_1_1_mifare_card_req.html#ac37a35ce68a57e1d4e0c398098fde93b", null ],
    [ "Password", "class_p_o_s_link2_1_1_device_1_1_mifare_card_req.html#ae5328c5050855da20018ea0d04f25da9", null ],
    [ "PasswordType", "class_p_o_s_link2_1_1_device_1_1_mifare_card_req.html#acc0826148fee7801131f31d7104f6389", null ],
    [ "Timeout", "class_p_o_s_link2_1_1_device_1_1_mifare_card_req.html#a6ec88ed2471acecaa20992d3dce272e9", null ],
    [ "UpdateBlockNo", "class_p_o_s_link2_1_1_device_1_1_mifare_card_req.html#ad5bfd863c9432adb69a6aba0b3ee0b77", null ]
];