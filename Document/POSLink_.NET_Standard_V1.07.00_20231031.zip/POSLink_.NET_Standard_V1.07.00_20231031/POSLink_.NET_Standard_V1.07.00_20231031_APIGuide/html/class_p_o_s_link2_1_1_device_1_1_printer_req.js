var class_p_o_s_link2_1_1_device_1_1_printer_req =
[
    [ "PrinterReq", "class_p_o_s_link2_1_1_device_1_1_printer_req.html#ab74a282a7430d3e8a42213bccec69d0d", null ],
    [ "PrintCopy", "class_p_o_s_link2_1_1_device_1_1_printer_req.html#af5a9321457524e3e0bc3d5b6b0394e99", null ],
    [ "PrintData", "class_p_o_s_link2_1_1_device_1_1_printer_req.html#a18dde700e867c3a0f782f9c06ddcd4a9", null ]
];