var class_p_o_s_link2_1_1_report_1_1_debit_totals =
[
    [ "AuthAmount", "class_p_o_s_link2_1_1_report_1_1_debit_totals.html#aa4f35e8ab2d5e82dc77b0e7746ac8887", null ],
    [ "AuthCount", "class_p_o_s_link2_1_1_report_1_1_debit_totals.html#ae570a105ca521571e3c560166de6cb22", null ],
    [ "PostauthAmount", "class_p_o_s_link2_1_1_report_1_1_debit_totals.html#ade220ed542b191e5fbe11993f3c9a6db", null ],
    [ "PostauthCount", "class_p_o_s_link2_1_1_report_1_1_debit_totals.html#a7e5987d9ae95316030b7d2588397542e", null ],
    [ "ReturnAmount", "class_p_o_s_link2_1_1_report_1_1_debit_totals.html#a814b76a08017d813a84b4f196c0f1a72", null ],
    [ "ReturnCount", "class_p_o_s_link2_1_1_report_1_1_debit_totals.html#a4d16709117ace21fc2d244179798984a", null ],
    [ "SaleAmount", "class_p_o_s_link2_1_1_report_1_1_debit_totals.html#a2ea310e27ebca9daf424c459c162199f", null ],
    [ "SaleCount", "class_p_o_s_link2_1_1_report_1_1_debit_totals.html#a771d86a85508f44dac95715309292c09", null ]
];