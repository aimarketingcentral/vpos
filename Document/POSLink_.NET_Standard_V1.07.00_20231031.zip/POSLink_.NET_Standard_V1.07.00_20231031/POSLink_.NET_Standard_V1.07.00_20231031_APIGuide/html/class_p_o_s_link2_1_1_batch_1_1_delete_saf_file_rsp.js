var class_p_o_s_link2_1_1_batch_1_1_delete_saf_file_rsp =
[
    [ "DeleteSafFileRsp", "class_p_o_s_link2_1_1_batch_1_1_delete_saf_file_rsp.html#a4ac1005847bed44e966eddd16e14331a", null ],
    [ "SafDeletedCount", "class_p_o_s_link2_1_1_batch_1_1_delete_saf_file_rsp.html#ab3163a0af237d9b1d559da78bbf790fc", null ],
    [ "TorInformation", "class_p_o_s_link2_1_1_batch_1_1_delete_saf_file_rsp.html#a5cdf1b0b68a338ab490cd409d7ff423d", null ]
];