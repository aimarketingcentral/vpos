var class_p_o_s_link2_1_1_batch_1_1_batch_clear_rsp =
[
    [ "BatchClearRsp", "class_p_o_s_link2_1_1_batch_1_1_batch_clear_rsp.html#a226f0f3ab7957189aa42730ddf7806ac", null ],
    [ "TorInformation", "class_p_o_s_link2_1_1_batch_1_1_batch_clear_rsp.html#af468742e6e974a65060f54788c98edec", null ]
];