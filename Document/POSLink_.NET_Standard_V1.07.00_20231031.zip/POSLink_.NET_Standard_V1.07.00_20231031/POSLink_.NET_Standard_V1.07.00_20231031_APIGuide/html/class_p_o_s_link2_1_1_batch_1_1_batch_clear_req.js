var class_p_o_s_link2_1_1_batch_1_1_batch_clear_req =
[
    [ "BatchClearReq", "class_p_o_s_link2_1_1_batch_1_1_batch_clear_req.html#af13942556b436cee193c05ca26682d81", null ],
    [ "EdcType", "class_p_o_s_link2_1_1_batch_1_1_batch_clear_req.html#a15dce8e8a116464a04da1c4e508fb1f7", null ]
];