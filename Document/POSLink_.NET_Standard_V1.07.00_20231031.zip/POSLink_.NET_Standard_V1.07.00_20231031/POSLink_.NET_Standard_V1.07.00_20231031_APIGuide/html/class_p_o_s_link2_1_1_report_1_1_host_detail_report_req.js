var class_p_o_s_link2_1_1_report_1_1_host_detail_report_req =
[
    [ "HostDetailReportReq", "class_p_o_s_link2_1_1_report_1_1_host_detail_report_req.html#a8e049374e06853ee4cc2171a7fc6bfdc", null ],
    [ "AuthCode", "class_p_o_s_link2_1_1_report_1_1_host_detail_report_req.html#a12e7c7593b36c8377dfdf2436c2325b2", null ],
    [ "CardType", "class_p_o_s_link2_1_1_report_1_1_host_detail_report_req.html#af76566b0e7ad9f659463a7ae883251c8", null ],
    [ "EcrTransId", "class_p_o_s_link2_1_1_report_1_1_host_detail_report_req.html#a80048cfa133843e16b3730d15d0d9d5f", null ],
    [ "EdcType", "class_p_o_s_link2_1_1_report_1_1_host_detail_report_req.html#add3af21c7a0b11de32d40b86eba4dd01", null ],
    [ "HRef", "class_p_o_s_link2_1_1_report_1_1_host_detail_report_req.html#a867a784f72115b3f5ef10efb0d7c897b", null ],
    [ "TransactionType", "class_p_o_s_link2_1_1_report_1_1_host_detail_report_req.html#a0ce7a05ff4b28a4b2c7bcc4d747382f8", null ]
];