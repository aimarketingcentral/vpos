var class_p_o_s_link2_1_1_manage_1_1_apple_pay_vas =
[
    [ "ApplePayVas", "class_p_o_s_link2_1_1_manage_1_1_apple_pay_vas.html#a1c88927068bd91504064006c880cc0a9", null ],
    [ "MerchantId", "class_p_o_s_link2_1_1_manage_1_1_apple_pay_vas.html#a1bd1a888cd4acadf938515bd1e359718", null ],
    [ "Url", "class_p_o_s_link2_1_1_manage_1_1_apple_pay_vas.html#a0626fdcd2923008adaa6702b37cf041e", null ],
    [ "UrlMode", "class_p_o_s_link2_1_1_manage_1_1_apple_pay_vas.html#a4de34600156b910db63506497b067b8b", null ]
];