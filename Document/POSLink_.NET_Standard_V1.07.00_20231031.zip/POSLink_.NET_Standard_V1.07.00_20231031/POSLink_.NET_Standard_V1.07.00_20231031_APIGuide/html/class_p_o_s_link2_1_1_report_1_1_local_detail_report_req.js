var class_p_o_s_link2_1_1_report_1_1_local_detail_report_req =
[
    [ "LocalDetailReportReq", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_req.html#ac3c9c110bf7651591bb276bf6d4311d5", null ],
    [ "AuthCode", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_req.html#aff8546d4e0e89378024b9928db2d9de4", null ],
    [ "CardType", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_req.html#a4743d5dddd59f91af88230103cc8c332", null ],
    [ "EcrRefNum", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_req.html#aa0927203c2042d23f99842046d74fb36", null ],
    [ "EdcType", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_req.html#a0fdbebfd720fd4e7586e423e4e7600c5", null ],
    [ "GlobalUid", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_req.html#a7dbdf2ba501b80318e920220ce01cbc8", null ],
    [ "LastTransaction", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_req.html#a69627e6373cf7fc2d43de9ebe9ba62e0", null ],
    [ "MultiMerchant", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_req.html#a751c207605831654f9da088c9356d2d1", null ],
    [ "OrigRefNum", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_req.html#a4e327a9dd96baea1f0a3cc37796ff885", null ],
    [ "RecordNumber", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_req.html#af4a359f673ed255fdac99ac6326f0142", null ],
    [ "TransactionResultType", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_req.html#a15e8a9bcedb8327c7b8afef83ca4b6a7", null ],
    [ "TransactionType", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_req.html#a2fd64e9d1f18f2228986a69988a4130f", null ]
];