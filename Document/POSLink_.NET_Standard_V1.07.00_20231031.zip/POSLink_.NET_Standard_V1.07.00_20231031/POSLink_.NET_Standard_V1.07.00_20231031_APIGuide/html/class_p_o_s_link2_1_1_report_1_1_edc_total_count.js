var class_p_o_s_link2_1_1_report_1_1_edc_total_count =
[
    [ "EdcTotalCount", "class_p_o_s_link2_1_1_report_1_1_edc_total_count.html#af3182d40bfb049f9d3ee4031e325c12a", null ],
    [ "CashCount", "class_p_o_s_link2_1_1_report_1_1_edc_total_count.html#a8382d1a3891672184d44a77508077087", null ],
    [ "CheckCount", "class_p_o_s_link2_1_1_report_1_1_edc_total_count.html#a7c7dd64dad309ed4048ba868b7424b8d", null ],
    [ "CreditCount", "class_p_o_s_link2_1_1_report_1_1_edc_total_count.html#a8790db3bba5b83522367a02f9bcc8033", null ],
    [ "DebitCount", "class_p_o_s_link2_1_1_report_1_1_edc_total_count.html#a153823285c7cd9c42df01252c53c795c", null ],
    [ "EbtCount", "class_p_o_s_link2_1_1_report_1_1_edc_total_count.html#a7359e3104a807631218fe21a43b34f55", null ],
    [ "GfitCount", "class_p_o_s_link2_1_1_report_1_1_edc_total_count.html#a787f60c0cedaef97a7951ed16eff023e", null ],
    [ "LoyaltyCount", "class_p_o_s_link2_1_1_report_1_1_edc_total_count.html#a0360366037b9e89484e0b6705833dcd6", null ]
];