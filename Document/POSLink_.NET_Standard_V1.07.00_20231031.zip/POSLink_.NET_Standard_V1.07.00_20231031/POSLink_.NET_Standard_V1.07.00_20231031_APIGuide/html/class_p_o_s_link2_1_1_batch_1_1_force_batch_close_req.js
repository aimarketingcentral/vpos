var class_p_o_s_link2_1_1_batch_1_1_force_batch_close_req =
[
    [ "ForceBatchCloseReq", "class_p_o_s_link2_1_1_batch_1_1_force_batch_close_req.html#aea96548b2a375031bb329cc4b8e963f9", null ],
    [ "TimeStamp", "class_p_o_s_link2_1_1_batch_1_1_force_batch_close_req.html#a550dc995bd1b229a3e2f0a9db1929ce1", null ]
];