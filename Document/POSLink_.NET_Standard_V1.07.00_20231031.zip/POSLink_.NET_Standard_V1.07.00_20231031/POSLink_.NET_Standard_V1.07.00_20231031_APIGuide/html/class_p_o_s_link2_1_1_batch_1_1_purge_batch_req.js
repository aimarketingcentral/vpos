var class_p_o_s_link2_1_1_batch_1_1_purge_batch_req =
[
    [ "PurgeBatchReq", "class_p_o_s_link2_1_1_batch_1_1_purge_batch_req.html#a03ef608ac63feec4e3bc2f0bfb3fa3e2", null ],
    [ "TimeStamp", "class_p_o_s_link2_1_1_batch_1_1_purge_batch_req.html#a77086a9b374b10543cc48b67f2ca3065", null ]
];