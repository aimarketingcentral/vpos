var class_p_o_s_link2_1_1_report_1_1_saf_summary_report_rsp =
[
    [ "SafSummaryReportRsp", "class_p_o_s_link2_1_1_report_1_1_saf_summary_report_rsp.html#a84a8f8ce4c3a916ff31577c0e4eb92cf", null ],
    [ "CardTotalAmount", "class_p_o_s_link2_1_1_report_1_1_saf_summary_report_rsp.html#a3d91d598becaaf20b006d269317aba4d", null ],
    [ "CardTotalCount", "class_p_o_s_link2_1_1_report_1_1_saf_summary_report_rsp.html#af99f884214214bc874b4589241b4096e", null ]
];