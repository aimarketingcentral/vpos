var class_p_o_s_link2_1_1_form_1_1_show_message_req =
[
    [ "ShowMessageReq", "class_p_o_s_link2_1_1_form_1_1_show_message_req.html#a2f41f0d415bf62cb868dcff9b857e307", null ],
    [ "DisplayMessage1", "class_p_o_s_link2_1_1_form_1_1_show_message_req.html#aac22fcfd8dbe5eb6674f4f7af9404854", null ],
    [ "DisplayMessage2", "class_p_o_s_link2_1_1_form_1_1_show_message_req.html#a4e0e73e753c42696d1f0853c9dc59dcc", null ],
    [ "ImageDescription", "class_p_o_s_link2_1_1_form_1_1_show_message_req.html#adf2cb640babce58ec1bd05696fa000c0", null ],
    [ "ImageName", "class_p_o_s_link2_1_1_form_1_1_show_message_req.html#ac0da9fc9042e3e5c51463a36e86b4365", null ],
    [ "ItemIndex", "class_p_o_s_link2_1_1_form_1_1_show_message_req.html#a8b87fc528af8661f196db46e036b7618", null ],
    [ "LineItemAction", "class_p_o_s_link2_1_1_form_1_1_show_message_req.html#a7a422b156bc8c3d96b314321c1fa0dbe", null ],
    [ "TaxLine", "class_p_o_s_link2_1_1_form_1_1_show_message_req.html#a65f6bfd5a596bb4b426bada692f8278c", null ],
    [ "Title", "class_p_o_s_link2_1_1_form_1_1_show_message_req.html#aca511a0c745cf5531fff5b3156bf61c1", null ],
    [ "TopDown", "class_p_o_s_link2_1_1_form_1_1_show_message_req.html#a3e500ff2eeabffba03d4758b65c821c2", null ],
    [ "TotalLine", "class_p_o_s_link2_1_1_form_1_1_show_message_req.html#a382d36cf6ecf8213618641f10837a3dd", null ]
];