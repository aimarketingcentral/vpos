var class_p_o_s_link2_1_1_form_1_1_show_text_box_rsp =
[
    [ "ShowTextBoxRsp", "class_p_o_s_link2_1_1_form_1_1_show_text_box_rsp.html#a9983ddf0f35329d0910d2d317d0ab515", null ],
    [ "ButtonNumber", "class_p_o_s_link2_1_1_form_1_1_show_text_box_rsp.html#af5e4da3e0e291acc9c5fe9749d3e6999", null ],
    [ "SignatureData", "class_p_o_s_link2_1_1_form_1_1_show_text_box_rsp.html#a3c54dd750123add5e0fb2d83376f89ed", null ],
    [ "SignStatus", "class_p_o_s_link2_1_1_form_1_1_show_text_box_rsp.html#a0e7f7ed0eeadb68a621721cd843cd890", null ],
    [ "Text", "class_p_o_s_link2_1_1_form_1_1_show_text_box_rsp.html#aac70a5850604bc7c0052c1b94517ca3f", null ]
];