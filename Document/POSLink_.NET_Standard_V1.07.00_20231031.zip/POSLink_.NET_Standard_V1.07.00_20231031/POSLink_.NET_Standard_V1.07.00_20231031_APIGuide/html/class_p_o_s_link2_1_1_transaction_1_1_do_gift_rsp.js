var class_p_o_s_link2_1_1_transaction_1_1_do_gift_rsp =
[
    [ "DoGiftRsp", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_rsp.html#aab099cf1846d57cfc1ee368cbdd3ddc4", null ],
    [ "AccountInformation", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_rsp.html#a26fa9bb6279d42a57351e6d7687e9538", null ],
    [ "AmountInformation", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_rsp.html#afb42b031eec46ea7b421a311bcb2f20e", null ],
    [ "CardInfo", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_rsp.html#a683f1eaa335e2ca1ea7dba5804741a53", null ],
    [ "FleetCard", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_rsp.html#a6358687118ff00e5dd64583ec55a1280", null ],
    [ "HostCredentialInformation", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_rsp.html#a29c3f68c1478b09e5c5c1879ed07a914", null ],
    [ "HostInformation", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_rsp.html#a04f399396d9cc49c066b0d3bd354d7cc", null ],
    [ "MultiMerchant", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_rsp.html#a42a4a0de7d72971e3a1ffaa29871ca7d", null ],
    [ "PaymentEmvTag", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_rsp.html#a89ff198ce13878e141033a838ed5d70a", null ],
    [ "PaymentTransInfo", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_rsp.html#a6f3f4d672d7ebc403e47a99b3a99ffdc", null ],
    [ "Restaurant", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_rsp.html#aa55cc0abecb4599728c5f951eb209c25", null ],
    [ "TorInformation", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_rsp.html#acddfc0d55060185446e41221e8816434", null ],
    [ "TraceInformation", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_rsp.html#a1eda9774575986d3e60d7ac25a851e56", null ],
    [ "TransactionType", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_rsp.html#a74bd06648b6ee9d2de476144d4174400", null ],
    [ "VasInformation", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_rsp.html#ae2afe62d92d395058afb90774dad0c29", null ]
];