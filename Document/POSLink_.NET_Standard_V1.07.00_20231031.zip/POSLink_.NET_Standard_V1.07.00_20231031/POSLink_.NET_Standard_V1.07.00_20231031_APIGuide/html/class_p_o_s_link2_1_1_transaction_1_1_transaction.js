var class_p_o_s_link2_1_1_transaction_1_1_transaction =
[
    [ "CheckCardType", "class_p_o_s_link2_1_1_transaction_1_1_transaction.html#a9539afce60dc3da1d21281333ea0d1ea", null ],
    [ "DoCash", "class_p_o_s_link2_1_1_transaction_1_1_transaction.html#a540a52591c8b59f87fd69d7af23c1a62", null ],
    [ "DoCheck", "class_p_o_s_link2_1_1_transaction_1_1_transaction.html#a865d7a4160565b9e86a68bed36c290ea", null ],
    [ "DoCredit", "class_p_o_s_link2_1_1_transaction_1_1_transaction.html#a54ade0ec1be8f4966174c3c96f78b53c", null ],
    [ "DoDebit", "class_p_o_s_link2_1_1_transaction_1_1_transaction.html#a5c417bb15dfd4137f9b3cad2215898bc", null ],
    [ "DoEbt", "class_p_o_s_link2_1_1_transaction_1_1_transaction.html#a2c3d3e9e113af257d6afb3d8036356ce", null ],
    [ "DoGift", "class_p_o_s_link2_1_1_transaction_1_1_transaction.html#a7de60d47523b1dc1d27df7eae7301357", null ],
    [ "DoLoyalty", "class_p_o_s_link2_1_1_transaction_1_1_transaction.html#adae47bd6e2673a525c4336ce802ad81c", null ]
];