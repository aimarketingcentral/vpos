var class_p_o_s_link2_1_1_transaction_1_1_do_gift_req =
[
    [ "DoGiftReq", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_req.html#a7784ab614b106d18aa347ac8d12fd1db", null ],
    [ "AccountInformation", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_req.html#a06b38b962750a6741a29631ee960dd2e", null ],
    [ "AmountInformation", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_req.html#af295a85156e231cfad42cb7168be5c96", null ],
    [ "CashierInformation", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_req.html#abd232893ec6a672f0bc8bc629102e1e3", null ],
    [ "ContinuousScreen", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_req.html#a570c8e55aa9fb51d634797549a0ff119", null ],
    [ "FleetCard", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_req.html#a9213ace11e6b7b464fed7d0eb078e310", null ],
    [ "HostCredential", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_req.html#a73fcd0736540ab57ca1faa4e61d7d31e", null ],
    [ "HostGateway", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_req.html#ade93be3ef8c3c43ef22bc54031c318c8", null ],
    [ "MultiMerchant", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_req.html#ab7a9b09eae919014be86fc3fc6476c19", null ],
    [ "Original", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_req.html#a1e0e4e4eb62d0be5303867e7549d0113", null ],
    [ "PosEchoData", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_req.html#afb4b7dda2ea051f49ff3ca768c34750f", null ],
    [ "Restaurant", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_req.html#aaebc2041432180655ffbcd2daff2992f", null ],
    [ "TraceInformation", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_req.html#ab6142cacb3e4d98c0415743d7a23ae08", null ],
    [ "TransactionBehavior", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_req.html#a6c93322a694e8a0873f0b09cf6d8bee3", null ],
    [ "TransactionType", "class_p_o_s_link2_1_1_transaction_1_1_do_gift_req.html#a96fdc921710b940b4cf42b141dfae939", null ]
];