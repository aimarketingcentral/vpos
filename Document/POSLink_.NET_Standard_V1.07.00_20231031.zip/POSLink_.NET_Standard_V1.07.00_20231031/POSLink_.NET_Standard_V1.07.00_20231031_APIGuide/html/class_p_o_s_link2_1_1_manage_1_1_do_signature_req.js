var class_p_o_s_link2_1_1_manage_1_1_do_signature_req =
[
    [ "DoSignatureReq", "class_p_o_s_link2_1_1_manage_1_1_do_signature_req.html#ab75beb5123664eb83f80cd3ec8a05961", null ],
    [ "ContinuousScreen", "class_p_o_s_link2_1_1_manage_1_1_do_signature_req.html#af06c356db1419d7c834bf2610fc87f7b", null ],
    [ "EdcType", "class_p_o_s_link2_1_1_manage_1_1_do_signature_req.html#a718c91e6fbc0c2e39541ceb015d01bb0", null ],
    [ "HRefNum", "class_p_o_s_link2_1_1_manage_1_1_do_signature_req.html#a43eec5ef234258efcba129e6ea3b7f3e", null ],
    [ "Timeout", "class_p_o_s_link2_1_1_manage_1_1_do_signature_req.html#ab50b0bae9adebe7dc35581ed1fdfdeb0", null ],
    [ "UploadFlag", "class_p_o_s_link2_1_1_manage_1_1_do_signature_req.html#a14a255552bca31d9036aa2d76794e4b0", null ]
];