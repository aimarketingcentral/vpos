var class_p_o_s_link2_1_1_batch_1_1_saf_upload_rsp =
[
    [ "SafUploadRsp", "class_p_o_s_link2_1_1_batch_1_1_saf_upload_rsp.html#af0126f2d147588ab11b53a1148d99ee8", null ],
    [ "SafFailedCount", "class_p_o_s_link2_1_1_batch_1_1_saf_upload_rsp.html#a94367fccf14840e68479eafcaf020cdd", null ],
    [ "SafFailedTotal", "class_p_o_s_link2_1_1_batch_1_1_saf_upload_rsp.html#a7ebf4c00f204d7ba8dfa7f9c7181c164", null ],
    [ "SafTotalAmount", "class_p_o_s_link2_1_1_batch_1_1_saf_upload_rsp.html#ab3da9bb63ada27c53fecb7f8aade6f8a", null ],
    [ "SafTotalCount", "class_p_o_s_link2_1_1_batch_1_1_saf_upload_rsp.html#a56aaf997736e2b8f12e3c75a37be2afb", null ],
    [ "SafUploadedAmount", "class_p_o_s_link2_1_1_batch_1_1_saf_upload_rsp.html#a61665121aa345e73956775f54e59c319", null ],
    [ "SafUploadedCount", "class_p_o_s_link2_1_1_batch_1_1_saf_upload_rsp.html#af445990d918bf9325ac24e3c0af09c23", null ],
    [ "TimeStamp", "class_p_o_s_link2_1_1_batch_1_1_saf_upload_rsp.html#ad6fd0ad567ced329ae83a06d8638928f", null ],
    [ "TorInformation", "class_p_o_s_link2_1_1_batch_1_1_saf_upload_rsp.html#a9195920786da2367b8603282f9a77a91", null ]
];