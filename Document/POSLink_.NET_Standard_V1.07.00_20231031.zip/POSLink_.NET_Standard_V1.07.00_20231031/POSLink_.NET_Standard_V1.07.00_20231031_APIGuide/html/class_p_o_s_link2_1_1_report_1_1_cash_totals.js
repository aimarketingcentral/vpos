var class_p_o_s_link2_1_1_report_1_1_cash_totals =
[
    [ "ReturnAmount", "class_p_o_s_link2_1_1_report_1_1_cash_totals.html#a041335bacd59f71d5a3fdce9e2c79496", null ],
    [ "ReturnCount", "class_p_o_s_link2_1_1_report_1_1_cash_totals.html#a63e5c7fd8b9c0e0cce2addf1931e6d20", null ],
    [ "SaleAmount", "class_p_o_s_link2_1_1_report_1_1_cash_totals.html#a38fe9759feee826ac4fcc011db0ab703", null ],
    [ "SaleCount", "class_p_o_s_link2_1_1_report_1_1_cash_totals.html#a511980e74b1ec6df40ffb1947332c308", null ]
];