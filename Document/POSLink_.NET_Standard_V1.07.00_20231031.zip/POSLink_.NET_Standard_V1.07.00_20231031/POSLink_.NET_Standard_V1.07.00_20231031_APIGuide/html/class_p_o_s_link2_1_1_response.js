var class_p_o_s_link2_1_1_response =
[
    [ "ResponseCode", "class_p_o_s_link2_1_1_response.html#abbf1963d0f766f15996e5d44fff2ec9c", null ],
    [ "ResponseMessage", "class_p_o_s_link2_1_1_response.html#a940a8ddf1fbad9e887d7b8a82746e296", null ]
];