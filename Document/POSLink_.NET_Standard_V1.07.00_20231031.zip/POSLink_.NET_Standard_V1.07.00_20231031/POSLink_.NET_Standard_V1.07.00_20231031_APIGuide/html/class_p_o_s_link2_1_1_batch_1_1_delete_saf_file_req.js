var class_p_o_s_link2_1_1_batch_1_1_delete_saf_file_req =
[
    [ "DeleteSafFileReq", "class_p_o_s_link2_1_1_batch_1_1_delete_saf_file_req.html#aa13f07f5bb2f12fbc437223e91c467dd", null ],
    [ "SafIndicator", "class_p_o_s_link2_1_1_batch_1_1_delete_saf_file_req.html#a1bcd03785f965c9e8fa37402fa763f03", null ]
];