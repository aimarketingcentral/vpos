var class_p_o_s_link2_1_1_manage_1_1_delete_image_rsp =
[
    [ "DeleteImageRsp", "class_p_o_s_link2_1_1_manage_1_1_delete_image_rsp.html#ae60fde59b6adafc385e35fe915fbc158", null ]
];