var class_p_o_s_link2_1_1_batch_1_1_delete_transaction_req =
[
    [ "DeleteTransactionReq", "class_p_o_s_link2_1_1_batch_1_1_delete_transaction_req.html#a3babfcb86be35170974235c797fdb859", null ],
    [ "AuthCode", "class_p_o_s_link2_1_1_batch_1_1_delete_transaction_req.html#a532e1a1c57cefe72f3b08da9dabb1fd2", null ],
    [ "CardType", "class_p_o_s_link2_1_1_batch_1_1_delete_transaction_req.html#add5f2e2e319bfb5914d4546c341d1c26", null ],
    [ "EcrRefNum", "class_p_o_s_link2_1_1_batch_1_1_delete_transaction_req.html#a0d80489d5c7545966d9aea50fd8efb5a", null ],
    [ "EdcType", "class_p_o_s_link2_1_1_batch_1_1_delete_transaction_req.html#ac1a9fc00145e1e762968aeec5341d127", null ],
    [ "OrigRefNum", "class_p_o_s_link2_1_1_batch_1_1_delete_transaction_req.html#ad1cf87c15a1d084edc0dd1502ddf306b", null ],
    [ "RecordNumber", "class_p_o_s_link2_1_1_batch_1_1_delete_transaction_req.html#a807ff5ad36bbdc3b60795cc7bbd6ba91", null ],
    [ "TransactionType", "class_p_o_s_link2_1_1_batch_1_1_delete_transaction_req.html#ac8e55883e98b5d7f9281949d69a2c2b5", null ]
];