var class_p_o_s_link2_1_1_execution_result =
[
    [ "Code", "class_p_o_s_link2_1_1_execution_result.html#af804674adcf5e300e91f06af75a1ea61", [
      [ "UnknownError", "class_p_o_s_link2_1_1_execution_result.html#af804674adcf5e300e91f06af75a1ea61abfaef30f1c8011c5cefa38ae470fb7aa", null ],
      [ "Ok", "class_p_o_s_link2_1_1_execution_result.html#af804674adcf5e300e91f06af75a1ea61aa60852f204ed8028c1c58808b746d115", null ],
      [ "RecvAckTimeout", "class_p_o_s_link2_1_1_execution_result.html#af804674adcf5e300e91f06af75a1ea61a64f7b187d9f00a8d1afe07bdebf24a48", null ],
      [ "RecvDataTimeout", "class_p_o_s_link2_1_1_execution_result.html#af804674adcf5e300e91f06af75a1ea61a621a686db5bbc0c6f95f1aba01374b0a", null ],
      [ "ConnectError", "class_p_o_s_link2_1_1_execution_result.html#af804674adcf5e300e91f06af75a1ea61a3b26f2ffccae97443db33944eda7b269", null ],
      [ "SendDataError", "class_p_o_s_link2_1_1_execution_result.html#af804674adcf5e300e91f06af75a1ea61ad1408f199a729af3889518489a7704e7", null ],
      [ "RecvAckError", "class_p_o_s_link2_1_1_execution_result.html#af804674adcf5e300e91f06af75a1ea61ad64496cda1723a6e08bfe33b0b5f43b8", null ],
      [ "RecvDataError", "class_p_o_s_link2_1_1_execution_result.html#af804674adcf5e300e91f06af75a1ea61abd7a50053743f744f680d35715940e75", null ],
      [ "ExceptionalHttpStatusCode", "class_p_o_s_link2_1_1_execution_result.html#af804674adcf5e300e91f06af75a1ea61ab8981b5b1d677724e9c89045314f553c", null ],
      [ "LrcError", "class_p_o_s_link2_1_1_execution_result.html#af804674adcf5e300e91f06af75a1ea61ab8ac96cd5233f4f13223a1d5b705b4a9", null ],
      [ "PackRequestError", "class_p_o_s_link2_1_1_execution_result.html#af804674adcf5e300e91f06af75a1ea61aec3fe7ae3177238b40fcaf7dd8f6a74d", null ]
    ] ],
    [ "ExecutionResult", "class_p_o_s_link2_1_1_execution_result.html#ae3218f6a70827971e7671168bfd5fac5", null ],
    [ "GetErrorCode", "class_p_o_s_link2_1_1_execution_result.html#ac26230b07e4a9d9e7111d6aabd8b6247", null ]
];