var class_p_o_s_link2_1_1_manage_1_1_new_service =
[
    [ "NewService", "class_p_o_s_link2_1_1_manage_1_1_new_service.html#adea83f5fd70c55ef1f540c439151f2a7", null ],
    [ "Title", "class_p_o_s_link2_1_1_manage_1_1_new_service.html#a9e023ef73d514715de478aa8b10e00df", null ],
    [ "Type", "class_p_o_s_link2_1_1_manage_1_1_new_service.html#a0ba5435ef071a34c0ed1b924e3469ed1", null ],
    [ "Url", "class_p_o_s_link2_1_1_manage_1_1_new_service.html#a493536a5edb5a5c4ee561638333ac9aa", null ]
];