var class_p_o_s_link2_1_1_report_1_1_local_failed_report_rsp =
[
    [ "LocalFailedReportRsp", "class_p_o_s_link2_1_1_report_1_1_local_failed_report_rsp.html#ad121cd39f1d37854250c713af5e3b14b", null ],
    [ "AccountInformation", "class_p_o_s_link2_1_1_report_1_1_local_failed_report_rsp.html#a2dba1a46fdda291b397c2f0381d1ca2f", null ],
    [ "AmountInformation", "class_p_o_s_link2_1_1_report_1_1_local_failed_report_rsp.html#a38f2f4853cfb074a5e6d793a7d2eade3", null ],
    [ "EdcType", "class_p_o_s_link2_1_1_report_1_1_local_failed_report_rsp.html#ad1bcee9d2030c69cbf1a7392c4bf0898", null ],
    [ "HostInformation", "class_p_o_s_link2_1_1_report_1_1_local_failed_report_rsp.html#a5990bd5e3cf2b4b6c30fa52b16f40f04", null ],
    [ "TraceInformation", "class_p_o_s_link2_1_1_report_1_1_local_failed_report_rsp.html#a112aa484dc89fc38ca82d120c1fcd6cb", null ],
    [ "TransactionType", "class_p_o_s_link2_1_1_report_1_1_local_failed_report_rsp.html#adaaa05b251de6415463f32157a9b8a43", null ]
];