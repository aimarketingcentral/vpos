var class_p_o_s_link2_1_1_transaction_1_1_do_loyalty_req =
[
    [ "DoLoyaltyReq", "class_p_o_s_link2_1_1_transaction_1_1_do_loyalty_req.html#a924c5fa7faa1035b8b1a4daaa3035868", null ],
    [ "AccountInformation", "class_p_o_s_link2_1_1_transaction_1_1_do_loyalty_req.html#ad91d5ec99afbd57149f6137c071c37d0", null ],
    [ "AmountInformation", "class_p_o_s_link2_1_1_transaction_1_1_do_loyalty_req.html#a9a3edf4fd7427d75cdbc5b15d8e0c271", null ],
    [ "CashierInformation", "class_p_o_s_link2_1_1_transaction_1_1_do_loyalty_req.html#ac336d6005650e958cfb9e922c81f5544", null ],
    [ "ContinuousScreen", "class_p_o_s_link2_1_1_transaction_1_1_do_loyalty_req.html#ab5e9c8ebdce31a32fb6dfdde15ceb1bd", null ],
    [ "FleetCard", "class_p_o_s_link2_1_1_transaction_1_1_do_loyalty_req.html#aa6a6323ee0c35e9997bff287ac048dc2", null ],
    [ "HostCredential", "class_p_o_s_link2_1_1_transaction_1_1_do_loyalty_req.html#a64716899083e3ab51b25128c4f528b98", null ],
    [ "HostGateway", "class_p_o_s_link2_1_1_transaction_1_1_do_loyalty_req.html#a0433dfd555730137f2908ff6966bbfa3", null ],
    [ "MultiMerchant", "class_p_o_s_link2_1_1_transaction_1_1_do_loyalty_req.html#a3d217a13c6654bab707581ea747587ef", null ],
    [ "Original", "class_p_o_s_link2_1_1_transaction_1_1_do_loyalty_req.html#a9b973883d5e6339b85be29a45ebc83f9", null ],
    [ "PosEchoData", "class_p_o_s_link2_1_1_transaction_1_1_do_loyalty_req.html#a56562c8977b5659f545470b00d8fbefa", null ],
    [ "Restaurant", "class_p_o_s_link2_1_1_transaction_1_1_do_loyalty_req.html#a1bd0258a2cad59f5c5d66f40e8eb69cc", null ],
    [ "TraceInformation", "class_p_o_s_link2_1_1_transaction_1_1_do_loyalty_req.html#aeb8e8358d7143ac720fd9cc3818a2f7f", null ],
    [ "TransactionBehavior", "class_p_o_s_link2_1_1_transaction_1_1_do_loyalty_req.html#abc8e59a940c9993f83555f75b948e576", null ],
    [ "TransactionType", "class_p_o_s_link2_1_1_transaction_1_1_do_loyalty_req.html#afad777a19591bce8a4c82b85c23e34e0", null ]
];