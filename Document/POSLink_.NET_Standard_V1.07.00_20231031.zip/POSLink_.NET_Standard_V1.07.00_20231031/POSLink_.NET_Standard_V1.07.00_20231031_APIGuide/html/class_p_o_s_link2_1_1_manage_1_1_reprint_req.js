var class_p_o_s_link2_1_1_manage_1_1_reprint_req =
[
    [ "ReprintReq", "class_p_o_s_link2_1_1_manage_1_1_reprint_req.html#aac2e672734b62954353ff2db909ad83e", null ],
    [ "AuthCode", "class_p_o_s_link2_1_1_manage_1_1_reprint_req.html#af52d4c0185d17b2f21a1021735fa0893", null ],
    [ "EcrRefNum", "class_p_o_s_link2_1_1_manage_1_1_reprint_req.html#afb65100bfde8c555a8a7475df42fea16", null ],
    [ "EdcType", "class_p_o_s_link2_1_1_manage_1_1_reprint_req.html#ae4509c483584aa034b34d712d3e65170", null ],
    [ "OrigRefNum", "class_p_o_s_link2_1_1_manage_1_1_reprint_req.html#a0d7a5404e7a091bd460b7d444d549707", null ],
    [ "PrintLastReceipt", "class_p_o_s_link2_1_1_manage_1_1_reprint_req.html#a2786fad239c5704f5ab6d15845682721", null ]
];