var class_p_o_s_link2_1_1_form_1_1_show_message_center_rsp =
[
    [ "ShowMessageCenterRsp", "class_p_o_s_link2_1_1_form_1_1_show_message_center_rsp.html#a233882807b20428da40afa9463cd7d09", null ],
    [ "PinpadType", "class_p_o_s_link2_1_1_form_1_1_show_message_center_rsp.html#a8a8ebcc7bf0821cf7f62f735482eca1d", null ]
];