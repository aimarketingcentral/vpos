var class_p_o_s_link2_1_1_report_1_1_ebt_totals =
[
    [ "AuthAmount", "class_p_o_s_link2_1_1_report_1_1_ebt_totals.html#a10df7b6932f854f1b4abbc1a6816a2db", null ],
    [ "AuthCount", "class_p_o_s_link2_1_1_report_1_1_ebt_totals.html#ad7eed354c00e625e302f09a3f9564d1b", null ],
    [ "PostauthAmount", "class_p_o_s_link2_1_1_report_1_1_ebt_totals.html#a139b5ffcbe55075967797fc930bc2473", null ],
    [ "PostauthCount", "class_p_o_s_link2_1_1_report_1_1_ebt_totals.html#af60073b89a306b924b31373c03b5acfa", null ],
    [ "ReturnAmount", "class_p_o_s_link2_1_1_report_1_1_ebt_totals.html#af12d5c63445a8989b2d5b4aef76a66ae", null ],
    [ "ReturnCount", "class_p_o_s_link2_1_1_report_1_1_ebt_totals.html#ac049f125647e7ed9fb26be76aaba383d", null ],
    [ "SaleAmount", "class_p_o_s_link2_1_1_report_1_1_ebt_totals.html#aaa6c8f0424f36b603c0f6019f5f74863", null ],
    [ "SaleCount", "class_p_o_s_link2_1_1_report_1_1_ebt_totals.html#aea324d590cb78235e442a01ea8b2144f", null ],
    [ "WithdrawalAmount", "class_p_o_s_link2_1_1_report_1_1_ebt_totals.html#ad8df953914db86aba873d290d178eade", null ],
    [ "WithdrawalCount", "class_p_o_s_link2_1_1_report_1_1_ebt_totals.html#a443f7b441a4f96a0da4e3a575309e304", null ]
];