var class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp =
[
    [ "LocalDetailReportRsp", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#a399606773f64c135f3913a91119224a3", null ],
    [ "AccountInformation", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#a53d1a6f8def7ddee5286ecbffa363c0a", null ],
    [ "AmountInformation", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#ada6dcea7a3c3993c093c832c9bd2b27b", null ],
    [ "CardInfo", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#a8e3553b96b74e7e7a4aece2f294b7ab0", null ],
    [ "CashierInformation", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#a3f0823de608e4b5ad03b8476711a76af", null ],
    [ "CheckInformation", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#acc4ff305bfd9568a0146e0c8da67c7bb", null ],
    [ "CommercialInformation", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#a68fc9715661e4513577db3f440faf731", null ],
    [ "EdcType", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#aad3b605bb550edcd31b35edbaaacb96d", null ],
    [ "FleetCard", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#aa6f559a3fab0a59295092835ccde40f1", null ],
    [ "HostInformation", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#a40e563d07fb41c3a22c7ec181bb4889d", null ],
    [ "MultiMerchant", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#a343934697eb45ab703ad7fb160da61e9", null ],
    [ "OriginalTransactionType", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#a749472f2bac420a1858fafa735618b1d", null ],
    [ "RecordNumber", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#a9c419427aed050c4fee46ea1bf3e1f08", null ],
    [ "ReportEmvTag", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#af57c47d6b6cc6b3eee22065d9e4ac337", null ],
    [ "ReportTransInfo", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#a0b5911994c5253a5d4eb196c8c75851a", null ],
    [ "Restaurant", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#afc0ccfed7b84a3b4ae7bb7b56e31cde5", null ],
    [ "TorInformation", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#a2171433ff7106d3d53f914a0a03959d7", null ],
    [ "TotalRecord", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#ab0d9f5f360cc569170cacd9e0a1da1e7", null ],
    [ "TraceInformation", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#a70ed138183d0f6bec1803da1c6096d75", null ],
    [ "TransactionType", "class_p_o_s_link2_1_1_report_1_1_local_detail_report_rsp.html#a00ad7c1eceb5be77f58c4538e6e55acb", null ]
];