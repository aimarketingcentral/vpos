var class_p_o_s_link2_1_1_device_1_1_camera_scan_req =
[
    [ "CameraScanReq", "class_p_o_s_link2_1_1_device_1_1_camera_scan_req.html#a95de6e9bac8fb43e5f23c38cee7cf5c2", null ],
    [ "Reader", "class_p_o_s_link2_1_1_device_1_1_camera_scan_req.html#aa78ac2b752d8558a15b6a27bd2085e73", null ],
    [ "Timeout", "class_p_o_s_link2_1_1_device_1_1_camera_scan_req.html#a6e3be9b642dc7b0a453b34b1889bbcb5", null ]
];