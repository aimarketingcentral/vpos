var class_p_o_s_link2_1_1_form_1_1_remove_card_rsp =
[
    [ "RemoveCardRsp", "class_p_o_s_link2_1_1_form_1_1_remove_card_rsp.html#aece14d8a1244d458ca976073a229a051", null ],
    [ "PinpadType", "class_p_o_s_link2_1_1_form_1_1_remove_card_rsp.html#a0a447c93d8d0ece331ef17d4d9e52633", null ]
];