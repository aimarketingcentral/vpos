var class_p_o_s_link2_1_1_report_1_1_history_report_rsp =
[
    [ "HistoryReportRsp", "class_p_o_s_link2_1_1_report_1_1_history_report_rsp.html#a633dd828a77ce4645487b8c919f4e26c", null ],
    [ "BatchNumber", "class_p_o_s_link2_1_1_report_1_1_history_report_rsp.html#ab2e36cbf6669026dc15e530c8e4a57d8", null ],
    [ "EdcTotalAmount", "class_p_o_s_link2_1_1_report_1_1_history_report_rsp.html#ae9081c5d6de15e76712eeb62c92be872", null ],
    [ "EdcTotalCount", "class_p_o_s_link2_1_1_report_1_1_history_report_rsp.html#a4027cb67ace5b74c087210a15eb7941d", null ],
    [ "TimeStamp", "class_p_o_s_link2_1_1_report_1_1_history_report_rsp.html#a31e99401ef11037c92ed5d3dc54e3495", null ]
];