var class_p_o_s_link2_1_1_report_1_1_local_total_report_req =
[
    [ "LocalTotalReportReq", "class_p_o_s_link2_1_1_report_1_1_local_total_report_req.html#aa9e24e2dc699bba9744bb5e8cb964511", null ],
    [ "CardType", "class_p_o_s_link2_1_1_report_1_1_local_total_report_req.html#a5e301204dfa7352a4091b76bc99e0f17", null ],
    [ "EdcType", "class_p_o_s_link2_1_1_report_1_1_local_total_report_req.html#abab0178313d281c62c00b164221e2370", null ]
];