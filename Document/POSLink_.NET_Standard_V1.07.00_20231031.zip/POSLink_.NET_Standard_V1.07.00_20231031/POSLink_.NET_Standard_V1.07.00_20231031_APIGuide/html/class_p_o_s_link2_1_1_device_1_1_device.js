var class_p_o_s_link2_1_1_device_1_1_device =
[
    [ "Camera", "class_p_o_s_link2_1_1_device_1_1_device.html#a9ac0a5ef86214fa6f1fed0c9523069da", null ],
    [ "Card", "class_p_o_s_link2_1_1_device_1_1_device.html#aa029ae26a94881457af76668afc6a06c", null ],
    [ "MifareCard", "class_p_o_s_link2_1_1_device_1_1_device.html#a55b486ad7b31fe09ef0464723b1b825f", null ],
    [ "Printer", "class_p_o_s_link2_1_1_device_1_1_device.html#a56817921cdfb9d53372e29f75fc834e5", null ]
];