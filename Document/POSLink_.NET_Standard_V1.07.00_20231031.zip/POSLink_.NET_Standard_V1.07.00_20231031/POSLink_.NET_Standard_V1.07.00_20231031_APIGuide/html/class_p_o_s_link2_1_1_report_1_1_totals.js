var class_p_o_s_link2_1_1_report_1_1_totals =
[
    [ "Totals", "class_p_o_s_link2_1_1_report_1_1_totals.html#a53c026e15d60c56a82630c08778a7bc9", null ],
    [ "CashTotals", "class_p_o_s_link2_1_1_report_1_1_totals.html#a02fb56744dfe3064c184a9b4270cc045", null ],
    [ "CheckTotals", "class_p_o_s_link2_1_1_report_1_1_totals.html#a3afb201c1f7f4f3d8edb95551b64d466", null ],
    [ "CreditTotals", "class_p_o_s_link2_1_1_report_1_1_totals.html#a550a3d9d4f96d073024acbb80b76c2b9", null ],
    [ "DebitTotals", "class_p_o_s_link2_1_1_report_1_1_totals.html#ab017df8cc3bc4464a0664aa07c4276ca", null ],
    [ "EbtTotals", "class_p_o_s_link2_1_1_report_1_1_totals.html#ab8d9647bf11bf779c83881ea814b8c82", null ],
    [ "GiftTotals", "class_p_o_s_link2_1_1_report_1_1_totals.html#a26df91e95ec1eca305464906b509e194", null ],
    [ "LoyaltyTotals", "class_p_o_s_link2_1_1_report_1_1_totals.html#a41bf939fe679c7771762b34aec537038", null ]
];