var class_p_o_s_link2_1_1_manage_1_1_update_resource_file_req =
[
    [ "UpdateResourceFileReq", "class_p_o_s_link2_1_1_manage_1_1_update_resource_file_req.html#a97fe737e2d2f1a6e628b3ab4ceddf07a", null ],
    [ "FileType", "class_p_o_s_link2_1_1_manage_1_1_update_resource_file_req.html#affd48e335cce179ca2c77c8a25c59e6a", null ],
    [ "FileUrl", "class_p_o_s_link2_1_1_manage_1_1_update_resource_file_req.html#a7f00c11c0d34b168626aa3aab5fe5f04", null ],
    [ "TargetDevice", "class_p_o_s_link2_1_1_manage_1_1_update_resource_file_req.html#a969cbd77ce13b674e4cfd4e20e5eedd3", null ]
];