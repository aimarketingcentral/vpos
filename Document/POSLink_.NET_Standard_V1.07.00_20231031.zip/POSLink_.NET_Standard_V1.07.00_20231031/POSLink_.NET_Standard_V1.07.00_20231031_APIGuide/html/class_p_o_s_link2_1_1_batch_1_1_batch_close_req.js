var class_p_o_s_link2_1_1_batch_1_1_batch_close_req =
[
    [ "BatchCloseReq", "class_p_o_s_link2_1_1_batch_1_1_batch_close_req.html#aee4f32f72aca52a1c1383c97606d0fa2", null ],
    [ "MultiMerchant", "class_p_o_s_link2_1_1_batch_1_1_batch_close_req.html#a41fadcf4d42f0c909c024c9102e27723", null ],
    [ "TimeStamp", "class_p_o_s_link2_1_1_batch_1_1_batch_close_req.html#ac27075bb3f696588394fb595687a5ae7", null ]
];